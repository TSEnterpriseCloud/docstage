'use strict';

var utils = require('../utils/writer.js');
var CustSupplDataInvoicePACO = require('../service/CustSupplDataInvoicePACOService');

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOGET = function apiV1EnvironmentCOCustSupplDataInvoicePACOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOIdDELETE = function apiV1EnvironmentCOCustSupplDataInvoicePACOIdDELETE (req, res, next, id, environment, tipocfCg44, codiceCg16, authorizationScope, company, user, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOIdDELETE(id, environment, tipocfCg44, codiceCg16, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOIdGET = function apiV1EnvironmentCOCustSupplDataInvoicePACOIdGET (req, res, next, id, environment, tipocfCg44, codiceCg16, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOIdGET(id, environment, tipocfCg44, codiceCg16, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOIdPATCH = function apiV1EnvironmentCOCustSupplDataInvoicePACOIdPATCH (req, res, next, body, force, _op, tipocfCg44, codiceCg16, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOIdPATCH(body, force, _op, tipocfCg44, codiceCg16, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOIdPUT = function apiV1EnvironmentCOCustSupplDataInvoicePACOIdPUT (req, res, next, body, force, _op, tipocfCg44, codiceCg16, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOIdPUT(body, force, _op, tipocfCg44, codiceCg16, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOPOST = function apiV1EnvironmentCOCustSupplDataInvoicePACOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePOST = function apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePOST (req, res, next, body, tipocfCg44, codiceCg16, company, user, environment, authorizationScope, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePOST(body, tipocfCg44, codiceCg16, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPOST = function apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPOST (req, res, next, body, tipocfCg44, codiceCg16, company, user, environment, authorizationScope, acceptLanguage) {
  CustSupplDataInvoicePACO.apiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPOST(body, tipocfCg44, codiceCg16, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
