'use strict';

var utils = require('../utils/writer.js');
var OfficeCO = require('../service/OfficeCOService');

module.exports.apiV1EnvironmentCOOfficeCOGET = function apiV1EnvironmentCOOfficeCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOIdDELETE = function apiV1EnvironmentCOOfficeCOIdDELETE (req, res, next, id, environment, dittaCg18, authorizationScope, company, user, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOIdDELETE(id, environment, dittaCg18, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOIdGET = function apiV1EnvironmentCOOfficeCOIdGET (req, res, next, id, environment, dittaCg18, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOIdGET(id, environment, dittaCg18, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOIdPATCH = function apiV1EnvironmentCOOfficeCOIdPATCH (req, res, next, body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOIdPATCH(body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOIdPUT = function apiV1EnvironmentCOOfficeCOIdPUT (req, res, next, body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOIdPUT(body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOPOST = function apiV1EnvironmentCOOfficeCOPOST (req, res, next, body, dittaCg18, company, user, environment, authorizationScope, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOPOST(body, dittaCg18, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOValidatePOST = function apiV1EnvironmentCOOfficeCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficeCOValidatePropertiesPOST = function apiV1EnvironmentCOOfficeCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  OfficeCO.apiV1EnvironmentCOOfficeCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
