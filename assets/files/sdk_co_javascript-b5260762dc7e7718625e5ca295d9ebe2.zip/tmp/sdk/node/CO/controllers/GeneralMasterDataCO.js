'use strict';

var utils = require('../utils/writer.js');
var GeneralMasterDataCO = require('../service/GeneralMasterDataCOService');

module.exports.apiV1EnvironmentCOGeneralMasterDataCOGET = function apiV1EnvironmentCOGeneralMasterDataCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOGetfromcervedPOST = function apiV1EnvironmentCOGeneralMasterDataCOGetfromcervedPOST (req, res, next, body, force, company, user, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOGetfromcervedPOST(body, force, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOIdDELETE = function apiV1EnvironmentCOGeneralMasterDataCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOIdGET = function apiV1EnvironmentCOGeneralMasterDataCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOIdPATCH = function apiV1EnvironmentCOGeneralMasterDataCOIdPATCH (req, res, next, body, force, _op, warnoverwriteinconsistentvalues, company, user, id, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOIdPATCH(body, force, _op, warnoverwriteinconsistentvalues, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOIdPUT = function apiV1EnvironmentCOGeneralMasterDataCOIdPUT (req, res, next, body, force, _op, warnoverwriteinconsistentvalues, company, user, id, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOIdPUT(body, force, _op, warnoverwriteinconsistentvalues, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOPOST = function apiV1EnvironmentCOGeneralMasterDataCOPOST (req, res, next, body, warnoverwriteinconsistentvalues, company, user, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOPOST(body, warnoverwriteinconsistentvalues, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOValidatePOST = function apiV1EnvironmentCOGeneralMasterDataCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOGeneralMasterDataCOValidatePropertiesPOST = function apiV1EnvironmentCOGeneralMasterDataCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  GeneralMasterDataCO.apiV1EnvironmentCOGeneralMasterDataCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
