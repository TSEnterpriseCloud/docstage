'use strict';

var utils = require('../utils/writer.js');
var AgentCO = require('../service/AgentCOService');

module.exports.apiV1EnvironmentCOAgentCOGET = function apiV1EnvironmentCOAgentCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOIdDELETE = function apiV1EnvironmentCOAgentCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOIdGET = function apiV1EnvironmentCOAgentCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOIdPATCH = function apiV1EnvironmentCOAgentCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOIdPUT = function apiV1EnvironmentCOAgentCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOPOST = function apiV1EnvironmentCOAgentCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOValidatePOST = function apiV1EnvironmentCOAgentCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgentCOValidatePropertiesPOST = function apiV1EnvironmentCOAgentCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgentCO.apiV1EnvironmentCOAgentCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
