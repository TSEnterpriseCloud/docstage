'use strict';

var utils = require('../utils/writer.js');
var BankCO = require('../service/BankCOService');

module.exports.apiV1EnvironmentCOBankCOGET = function apiV1EnvironmentCOBankCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOIdDELETE = function apiV1EnvironmentCOBankCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOIdGET = function apiV1EnvironmentCOBankCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOIdPATCH = function apiV1EnvironmentCOBankCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOIdPUT = function apiV1EnvironmentCOBankCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOPOST = function apiV1EnvironmentCOBankCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOValidatePOST = function apiV1EnvironmentCOBankCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOBankCOValidatePropertiesPOST = function apiV1EnvironmentCOBankCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  BankCO.apiV1EnvironmentCOBankCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
