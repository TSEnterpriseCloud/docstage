'use strict';

var utils = require('../utils/writer.js');
var IEStructureTypeCO = require('../service/IEStructureTypeCOService');

module.exports.apiV1EnvironmentCOIEStructureTypeCOIdGET = function apiV1EnvironmentCOIEStructureTypeCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  IEStructureTypeCO.apiV1EnvironmentCOIEStructureTypeCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
