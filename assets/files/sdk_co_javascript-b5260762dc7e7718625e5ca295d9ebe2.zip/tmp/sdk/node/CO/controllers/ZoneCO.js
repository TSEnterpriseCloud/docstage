'use strict';

var utils = require('../utils/writer.js');
var ZoneCO = require('../service/ZoneCOService');

module.exports.apiV1EnvironmentCOZoneCOGET = function apiV1EnvironmentCOZoneCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOIdDELETE = function apiV1EnvironmentCOZoneCOIdDELETE (req, res, next, id, environment, tipocfMg08, macroareaMg08, areaMg08, authorizationScope, company, user, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOIdDELETE(id, environment, tipocfMg08, macroareaMg08, areaMg08, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOIdGET = function apiV1EnvironmentCOZoneCOIdGET (req, res, next, id, environment, tipocfMg08, macroareaMg08, areaMg08, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOIdGET(id, environment, tipocfMg08, macroareaMg08, areaMg08, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOIdPATCH = function apiV1EnvironmentCOZoneCOIdPATCH (req, res, next, body, force, _op, tipocfMg08, macroareaMg08, areaMg08, company, user, id, environment, authorizationScope, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOIdPATCH(body, force, _op, tipocfMg08, macroareaMg08, areaMg08, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOIdPUT = function apiV1EnvironmentCOZoneCOIdPUT (req, res, next, body, force, _op, tipocfMg08, macroareaMg08, areaMg08, company, user, id, environment, authorizationScope, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOIdPUT(body, force, _op, tipocfMg08, macroareaMg08, areaMg08, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOPOST = function apiV1EnvironmentCOZoneCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOValidatePOST = function apiV1EnvironmentCOZoneCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOZoneCOValidatePropertiesPOST = function apiV1EnvironmentCOZoneCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ZoneCO.apiV1EnvironmentCOZoneCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
