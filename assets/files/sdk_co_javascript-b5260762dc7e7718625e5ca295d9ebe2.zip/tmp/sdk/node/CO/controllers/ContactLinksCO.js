'use strict';

var utils = require('../utils/writer.js');
var ContactLinksCO = require('../service/ContactLinksCOService');

module.exports.apiV1EnvironmentCOContactLinksCOGET = function apiV1EnvironmentCOContactLinksCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOIdDELETE = function apiV1EnvironmentCOContactLinksCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOIdGET = function apiV1EnvironmentCOContactLinksCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOIdPATCH = function apiV1EnvironmentCOContactLinksCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOIdPUT = function apiV1EnvironmentCOContactLinksCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOPOST = function apiV1EnvironmentCOContactLinksCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOValidatePOST = function apiV1EnvironmentCOContactLinksCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactLinksCOValidatePropertiesPOST = function apiV1EnvironmentCOContactLinksCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactLinksCO.apiV1EnvironmentCOContactLinksCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
