'use strict';

var utils = require('../utils/writer.js');
var UnitOfMeasureCO = require('../service/UnitOfMeasureCOService');

module.exports.apiV1EnvironmentCOUnitOfMeasureCOGET = function apiV1EnvironmentCOUnitOfMeasureCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOIdDELETE = function apiV1EnvironmentCOUnitOfMeasureCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOIdGET = function apiV1EnvironmentCOUnitOfMeasureCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOIdPATCH = function apiV1EnvironmentCOUnitOfMeasureCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOIdPUT = function apiV1EnvironmentCOUnitOfMeasureCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOPOST = function apiV1EnvironmentCOUnitOfMeasureCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOValidatePOST = function apiV1EnvironmentCOUnitOfMeasureCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOUnitOfMeasureCOValidatePropertiesPOST = function apiV1EnvironmentCOUnitOfMeasureCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  UnitOfMeasureCO.apiV1EnvironmentCOUnitOfMeasureCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
