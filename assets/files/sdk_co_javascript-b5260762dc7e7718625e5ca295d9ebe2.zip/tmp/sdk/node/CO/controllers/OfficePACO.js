'use strict';

var utils = require('../utils/writer.js');
var OfficePACO = require('../service/OfficePACOService');

module.exports.apiV1EnvironmentCOOfficePACOGET = function apiV1EnvironmentCOOfficePACOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOIdDELETE = function apiV1EnvironmentCOOfficePACOIdDELETE (req, res, next, id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, company, user, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOIdDELETE(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOIdGET = function apiV1EnvironmentCOOfficePACOIdGET (req, res, next, id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOIdGET(id, environment, tipocfCg44, codiceCg16, codDestin, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOIdPATCH = function apiV1EnvironmentCOOfficePACOIdPATCH (req, res, next, body, force, _op, tipocfCg44, codiceCg16, codDestin, company, user, id, environment, authorizationScope, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOIdPATCH(body, force, _op, tipocfCg44, codiceCg16, codDestin, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOIdPUT = function apiV1EnvironmentCOOfficePACOIdPUT (req, res, next, body, force, _op, tipocfCg44, codiceCg16, codDestin, company, user, id, environment, authorizationScope, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOIdPUT(body, force, _op, tipocfCg44, codiceCg16, codDestin, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOPOST = function apiV1EnvironmentCOOfficePACOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOValidatePOST = function apiV1EnvironmentCOOfficePACOValidatePOST (req, res, next, body, tipocfCg44, codiceCg16, codDestin, company, user, environment, authorizationScope, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOValidatePOST(body, tipocfCg44, codiceCg16, codDestin, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOOfficePACOValidatePropertiesPOST = function apiV1EnvironmentCOOfficePACOValidatePropertiesPOST (req, res, next, body, tipocfCg44, codiceCg16, codDestin, company, user, environment, authorizationScope, acceptLanguage) {
  OfficePACO.apiV1EnvironmentCOOfficePACOValidatePropertiesPOST(body, tipocfCg44, codiceCg16, codDestin, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
