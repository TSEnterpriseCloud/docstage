'use strict';

var utils = require('../utils/writer.js');
var MacroCategoryCO = require('../service/MacroCategoryCOService');

module.exports.apiV1EnvironmentCOMacroCategoryCOGET = function apiV1EnvironmentCOMacroCategoryCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOIdDELETE = function apiV1EnvironmentCOMacroCategoryCOIdDELETE (req, res, next, id, environment, tipocf, authorizationScope, company, user, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOIdDELETE(id, environment, tipocf, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOIdGET = function apiV1EnvironmentCOMacroCategoryCOIdGET (req, res, next, id, environment, tipocf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOIdGET(id, environment, tipocf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOIdPATCH = function apiV1EnvironmentCOMacroCategoryCOIdPATCH (req, res, next, body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOIdPATCH(body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOIdPUT = function apiV1EnvironmentCOMacroCategoryCOIdPUT (req, res, next, body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOIdPUT(body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOPOST = function apiV1EnvironmentCOMacroCategoryCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOValidatePOST = function apiV1EnvironmentCOMacroCategoryCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroCategoryCOValidatePropertiesPOST = function apiV1EnvironmentCOMacroCategoryCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroCategoryCO.apiV1EnvironmentCOMacroCategoryCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
