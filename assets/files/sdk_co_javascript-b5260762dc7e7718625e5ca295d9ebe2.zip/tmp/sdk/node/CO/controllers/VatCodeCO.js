'use strict';

var utils = require('../utils/writer.js');
var VatCodeCO = require('../service/VatCodeCOService');

module.exports.apiV1EnvironmentCOVatCodeCOGET = function apiV1EnvironmentCOVatCodeCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOIdDELETE = function apiV1EnvironmentCOVatCodeCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOIdGET = function apiV1EnvironmentCOVatCodeCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOIdPATCH = function apiV1EnvironmentCOVatCodeCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOIdPUT = function apiV1EnvironmentCOVatCodeCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOIdVerifica_movimentazione_progressiviPOST = function apiV1EnvironmentCOVatCodeCOIdVerifica_movimentazione_progressiviPOST (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOIdVerifica_movimentazione_progressiviPOST(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOPOST = function apiV1EnvironmentCOVatCodeCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOValidatePOST = function apiV1EnvironmentCOVatCodeCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOValidatePropertiesPOST = function apiV1EnvironmentCOVatCodeCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOVatCodeCOVatCodeDuplicationPOST = function apiV1EnvironmentCOVatCodeCOVatCodeDuplicationPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  VatCodeCO.apiV1EnvironmentCOVatCodeCOVatCodeDuplicationPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
