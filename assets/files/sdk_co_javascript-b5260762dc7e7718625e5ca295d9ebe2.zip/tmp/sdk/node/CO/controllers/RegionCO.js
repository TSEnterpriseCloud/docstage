'use strict';

var utils = require('../utils/writer.js');
var RegionCO = require('../service/RegionCOService');

module.exports.apiV1EnvironmentCORegionCOIdGET = function apiV1EnvironmentCORegionCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  RegionCO.apiV1EnvironmentCORegionCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
