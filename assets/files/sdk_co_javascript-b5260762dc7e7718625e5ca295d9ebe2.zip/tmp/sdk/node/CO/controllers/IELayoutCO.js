'use strict';

var utils = require('../utils/writer.js');
var IELayoutCO = require('../service/IELayoutCOService');

module.exports.apiV1EnvironmentCOIELayoutCOIdGET = function apiV1EnvironmentCOIELayoutCOIdGET (req, res, next, id, environment, codStructureType, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  IELayoutCO.apiV1EnvironmentCOIELayoutCOIdGET(id, environment, codStructureType, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
