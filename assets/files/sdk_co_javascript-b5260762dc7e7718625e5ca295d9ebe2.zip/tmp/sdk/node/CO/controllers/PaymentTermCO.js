'use strict';

var utils = require('../utils/writer.js');
var PaymentTermCO = require('../service/PaymentTermCOService');

module.exports.apiV1EnvironmentCOPaymentTermCOCalculate_sumPOST = function apiV1EnvironmentCOPaymentTermCOCalculate_sumPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOCalculate_sumPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOGET = function apiV1EnvironmentCOPaymentTermCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOGet_from_codePOST = function apiV1EnvironmentCOPaymentTermCOGet_from_codePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOGet_from_codePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOIdDELETE = function apiV1EnvironmentCOPaymentTermCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOIdGET = function apiV1EnvironmentCOPaymentTermCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOIdPATCH = function apiV1EnvironmentCOPaymentTermCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOIdPUT = function apiV1EnvironmentCOPaymentTermCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOPOST = function apiV1EnvironmentCOPaymentTermCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPOST = function apiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOPaymentTermDuplicationPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOValidatePOST = function apiV1EnvironmentCOPaymentTermCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOPaymentTermCOValidatePropertiesPOST = function apiV1EnvironmentCOPaymentTermCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PaymentTermCO.apiV1EnvironmentCOPaymentTermCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
