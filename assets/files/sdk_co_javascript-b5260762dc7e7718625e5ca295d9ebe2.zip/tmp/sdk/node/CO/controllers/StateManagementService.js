'use strict';

var utils = require('../utils/writer.js');
var StateManagementService = require('../service/StateManagementServiceService');

module.exports.apiV1EnvironmentCOStateManagementServiceGuidGET = function apiV1EnvironmentCOStateManagementServiceGuidGET (req, res, next, guid, environment, authorizationScope, company, user, acceptLanguage) {
  StateManagementService.apiV1EnvironmentCOStateManagementServiceGuidGET(guid, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOStateManagementServiceHistoryGuidGET = function apiV1EnvironmentCOStateManagementServiceHistoryGuidGET (req, res, next, guid, environment, authorizationScope, company, user, acceptLanguage) {
  StateManagementService.apiV1EnvironmentCOStateManagementServiceHistoryGuidGET(guid, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOStateManagementServiceSetstatePOST = function apiV1EnvironmentCOStateManagementServiceSetstatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  StateManagementService.apiV1EnvironmentCOStateManagementServiceSetstatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
