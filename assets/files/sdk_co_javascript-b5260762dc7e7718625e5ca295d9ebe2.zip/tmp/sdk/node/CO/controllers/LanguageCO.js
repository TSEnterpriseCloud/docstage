'use strict';

var utils = require('../utils/writer.js');
var LanguageCO = require('../service/LanguageCOService');

module.exports.apiV1EnvironmentCOLanguageCOGET = function apiV1EnvironmentCOLanguageCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOIdDELETE = function apiV1EnvironmentCOLanguageCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOIdGET = function apiV1EnvironmentCOLanguageCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOIdPATCH = function apiV1EnvironmentCOLanguageCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOIdPUT = function apiV1EnvironmentCOLanguageCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOPOST = function apiV1EnvironmentCOLanguageCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOValidatePOST = function apiV1EnvironmentCOLanguageCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOLanguageCOValidatePropertiesPOST = function apiV1EnvironmentCOLanguageCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  LanguageCO.apiV1EnvironmentCOLanguageCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
