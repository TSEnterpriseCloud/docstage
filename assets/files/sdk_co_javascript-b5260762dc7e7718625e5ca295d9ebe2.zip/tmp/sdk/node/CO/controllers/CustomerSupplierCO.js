'use strict';

var utils = require('../utils/writer.js');
var CustomerSupplierCO = require('../service/CustomerSupplierCOService');

module.exports.apiV1EnvironmentCOCustomerSupplierCOCreateintegrativedeclaretionPOST = function apiV1EnvironmentCOCustomerSupplierCOCreateintegrativedeclaretionPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOCreateintegrativedeclaretionPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOGET = function apiV1EnvironmentCOCustomerSupplierCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOGetcswitheffectivepaymentconditionPOST = function apiV1EnvironmentCOCustomerSupplierCOGetcswitheffectivepaymentconditionPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOGetcswitheffectivepaymentconditionPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOGetdefaultrevenueagencyPOST = function apiV1EnvironmentCOCustomerSupplierCOGetdefaultrevenueagencyPOST (req, res, next, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOGetdefaultrevenueagencyPOST(environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOGetfirstavailablenumnsprotletterofintentPOST = function apiV1EnvironmentCOCustomerSupplierCOGetfirstavailablenumnsprotletterofintentPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOGetfirstavailablenumnsprotletterofintentPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdChkjointlyheldexistPOST = function apiV1EnvironmentCOCustomerSupplierCOIdChkjointlyheldexistPOST (req, res, next, body, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdChkjointlyheldexistPOST(body, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdDELETE = function apiV1EnvironmentCOCustomerSupplierCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdDeleteallcsjointlyheldPOST = function apiV1EnvironmentCOCustomerSupplierCOIdDeleteallcsjointlyheldPOST (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdDeleteallcsjointlyheldPOST(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdGET = function apiV1EnvironmentCOCustomerSupplierCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdGetnewcodscaglPOST = function apiV1EnvironmentCOCustomerSupplierCOIdGetnewcodscaglPOST (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdGetnewcodscaglPOST(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdPATCH = function apiV1EnvironmentCOCustomerSupplierCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOIdPUT = function apiV1EnvironmentCOCustomerSupplierCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOInsertsendingletterPOST = function apiV1EnvironmentCOCustomerSupplierCOInsertsendingletterPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOInsertsendingletterPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOPOST = function apiV1EnvironmentCOCustomerSupplierCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOUpdatevaluesaftergeneratesendingletterPOST = function apiV1EnvironmentCOCustomerSupplierCOUpdatevaluesaftergeneratesendingletterPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOUpdatevaluesaftergeneratesendingletterPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOValidatePOST = function apiV1EnvironmentCOCustomerSupplierCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCustomerSupplierCOValidatePropertiesPOST = function apiV1EnvironmentCOCustomerSupplierCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierCO.apiV1EnvironmentCOCustomerSupplierCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
