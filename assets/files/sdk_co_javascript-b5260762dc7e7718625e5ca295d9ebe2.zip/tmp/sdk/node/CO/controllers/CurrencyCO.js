'use strict';

var utils = require('../utils/writer.js');
var CurrencyCO = require('../service/CurrencyCOService');

module.exports.apiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPOST = function apiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOCalculateAmountByCurrencyPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOCalculate_exchangeratePOST = function apiV1EnvironmentCOCurrencyCOCalculate_exchangeratePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOCalculate_exchangeratePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOGET = function apiV1EnvironmentCOCurrencyCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOIdDELETE = function apiV1EnvironmentCOCurrencyCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOIdGET = function apiV1EnvironmentCOCurrencyCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOIdPATCH = function apiV1EnvironmentCOCurrencyCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOIdPUT = function apiV1EnvironmentCOCurrencyCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOImportannualaverageratesPOST = function apiV1EnvironmentCOCurrencyCOImportannualaverageratesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOImportannualaverageratesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOImportcurrencyratesPOST = function apiV1EnvironmentCOCurrencyCOImportcurrencyratesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOImportcurrencyratesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPOST = function apiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOImportmonthlyaverageratesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOImporttimeseriesratesPOST = function apiV1EnvironmentCOCurrencyCOImporttimeseriesratesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOImporttimeseriesratesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOPOST = function apiV1EnvironmentCOCurrencyCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOValidatePOST = function apiV1EnvironmentCOCurrencyCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCurrencyCOValidatePropertiesPOST = function apiV1EnvironmentCOCurrencyCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CurrencyCO.apiV1EnvironmentCOCurrencyCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
