'use strict';

var utils = require('../utils/writer.js');
var IEExportCO = require('../service/IEExportCOService');

module.exports.apiV1EnvironmentCOIEExportCOCustomersupplierPOST = function apiV1EnvironmentCOIEExportCOCustomersupplierPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  IEExportCO.apiV1EnvironmentCOIEExportCOCustomersupplierPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
