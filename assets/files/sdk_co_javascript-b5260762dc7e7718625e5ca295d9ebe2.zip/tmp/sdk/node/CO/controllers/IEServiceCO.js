'use strict';

var utils = require('../utils/writer.js');
var IEServiceCO = require('../service/IEServiceCOService');

module.exports.apiV1EnvironmentCOIEServiceCOGuidProcessGET = function apiV1EnvironmentCOIEServiceCOGuidProcessGET (req, res, next, guidProcess, environment, authorizationScope, company, user, acceptLanguage) {
  IEServiceCO.apiV1EnvironmentCOIEServiceCOGuidProcessGET(guidProcess, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
