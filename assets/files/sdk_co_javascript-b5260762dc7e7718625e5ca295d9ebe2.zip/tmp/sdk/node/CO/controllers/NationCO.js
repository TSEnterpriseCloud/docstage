'use strict';

var utils = require('../utils/writer.js');
var NationCO = require('../service/NationCOService');

module.exports.apiV1EnvironmentCONationCOGET = function apiV1EnvironmentCONationCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOIdDELETE = function apiV1EnvironmentCONationCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOIdGET = function apiV1EnvironmentCONationCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOIdPATCH = function apiV1EnvironmentCONationCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOIdPUT = function apiV1EnvironmentCONationCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOPOST = function apiV1EnvironmentCONationCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOValidatePOST = function apiV1EnvironmentCONationCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCONationCOValidatePropertiesPOST = function apiV1EnvironmentCONationCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  NationCO.apiV1EnvironmentCONationCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
