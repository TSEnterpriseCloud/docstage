'use strict';

var utils = require('../utils/writer.js');
var SubCategoryCO = require('../service/SubCategoryCOService');

module.exports.apiV1EnvironmentCOSubCategoryCOGET = function apiV1EnvironmentCOSubCategoryCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOIdDELETE = function apiV1EnvironmentCOSubCategoryCOIdDELETE (req, res, next, id, environment, tipocfMg11, categMg11, macrocatMg11, authorizationScope, company, user, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOIdDELETE(id, environment, tipocfMg11, categMg11, macrocatMg11, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOIdGET = function apiV1EnvironmentCOSubCategoryCOIdGET (req, res, next, id, environment, tipocfMg11, categMg11, macrocatMg11, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOIdGET(id, environment, tipocfMg11, categMg11, macrocatMg11, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOIdPATCH = function apiV1EnvironmentCOSubCategoryCOIdPATCH (req, res, next, body, force, _op, tipocfMg11, categMg11, macrocatMg11, company, user, id, environment, authorizationScope, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOIdPATCH(body, force, _op, tipocfMg11, categMg11, macrocatMg11, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOIdPUT = function apiV1EnvironmentCOSubCategoryCOIdPUT (req, res, next, body, force, _op, tipocfMg11, categMg11, macrocatMg11, company, user, id, environment, authorizationScope, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOIdPUT(body, force, _op, tipocfMg11, categMg11, macrocatMg11, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOPOST = function apiV1EnvironmentCOSubCategoryCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOValidatePOST = function apiV1EnvironmentCOSubCategoryCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSubCategoryCOValidatePropertiesPOST = function apiV1EnvironmentCOSubCategoryCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SubCategoryCO.apiV1EnvironmentCOSubCategoryCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
