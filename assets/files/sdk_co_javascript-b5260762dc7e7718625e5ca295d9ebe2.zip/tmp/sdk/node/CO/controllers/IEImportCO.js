'use strict';

var utils = require('../utils/writer.js');
var IEImportCO = require('../service/IEImportCOService');

module.exports.apiV1EnvironmentCOIEImportCOCustomersupplierPOST = function apiV1EnvironmentCOIEImportCOCustomersupplierPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  IEImportCO.apiV1EnvironmentCOIEImportCOCustomersupplierPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
