'use strict';

var utils = require('../utils/writer.js');
var AgencyCO = require('../service/AgencyCOService');

module.exports.apiV1EnvironmentCOAgencyCOGET = function apiV1EnvironmentCOAgencyCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOIdDELETE = function apiV1EnvironmentCOAgencyCOIdDELETE (req, res, next, id, environment, codBanca, authorizationScope, company, user, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOIdDELETE(id, environment, codBanca, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOIdGET = function apiV1EnvironmentCOAgencyCOIdGET (req, res, next, id, environment, codBanca, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOIdGET(id, environment, codBanca, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOIdPATCH = function apiV1EnvironmentCOAgencyCOIdPATCH (req, res, next, body, force, _op, codBanca, company, user, id, environment, authorizationScope, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOIdPATCH(body, force, _op, codBanca, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOIdPUT = function apiV1EnvironmentCOAgencyCOIdPUT (req, res, next, body, force, _op, codBanca, company, user, id, environment, authorizationScope, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOIdPUT(body, force, _op, codBanca, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOPOST = function apiV1EnvironmentCOAgencyCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOValidatePOST = function apiV1EnvironmentCOAgencyCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAgencyCOValidatePropertiesPOST = function apiV1EnvironmentCOAgencyCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AgencyCO.apiV1EnvironmentCOAgencyCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
