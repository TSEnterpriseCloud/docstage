'use strict';

var utils = require('../utils/writer.js');
var SectionalMasterDataCO = require('../service/SectionalMasterDataCOService');

module.exports.apiV1EnvironmentCOSectionalMasterDataCOGET = function apiV1EnvironmentCOSectionalMasterDataCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOGet_SectionalMasterDataProposalPOST = function apiV1EnvironmentCOSectionalMasterDataCOGet_SectionalMasterDataProposalPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOGet_SectionalMasterDataProposalPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOIdDELETE = function apiV1EnvironmentCOSectionalMasterDataCOIdDELETE (req, res, next, id, environment, dittaCg18, authorizationScope, company, user, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOIdDELETE(id, environment, dittaCg18, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOIdGET = function apiV1EnvironmentCOSectionalMasterDataCOIdGET (req, res, next, id, environment, dittaCg18, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOIdGET(id, environment, dittaCg18, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOIdPATCH = function apiV1EnvironmentCOSectionalMasterDataCOIdPATCH (req, res, next, body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOIdPATCH(body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOIdPUT = function apiV1EnvironmentCOSectionalMasterDataCOIdPUT (req, res, next, body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOIdPUT(body, force, _op, dittaCg18, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOPOST = function apiV1EnvironmentCOSectionalMasterDataCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOValidatePOST = function apiV1EnvironmentCOSectionalMasterDataCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPOST = function apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  SectionalMasterDataCO.apiV1EnvironmentCOSectionalMasterDataCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
