'use strict';

var utils = require('../utils/writer.js');
var CategoryCO = require('../service/CategoryCOService');

module.exports.apiV1EnvironmentCOCategoryCOGET = function apiV1EnvironmentCOCategoryCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOIdDELETE = function apiV1EnvironmentCOCategoryCOIdDELETE (req, res, next, id, environment, tipocfMg10, macrocatMg10, authorizationScope, company, user, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOIdDELETE(id, environment, tipocfMg10, macrocatMg10, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOIdGET = function apiV1EnvironmentCOCategoryCOIdGET (req, res, next, id, environment, tipocfMg10, macrocatMg10, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOIdGET(id, environment, tipocfMg10, macrocatMg10, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOIdPATCH = function apiV1EnvironmentCOCategoryCOIdPATCH (req, res, next, body, force, _op, tipocfMg10, macrocatMg10, company, user, id, environment, authorizationScope, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOIdPATCH(body, force, _op, tipocfMg10, macrocatMg10, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOIdPUT = function apiV1EnvironmentCOCategoryCOIdPUT (req, res, next, body, force, _op, tipocfMg10, macrocatMg10, company, user, id, environment, authorizationScope, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOIdPUT(body, force, _op, tipocfMg10, macrocatMg10, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOPOST = function apiV1EnvironmentCOCategoryCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOValidatePOST = function apiV1EnvironmentCOCategoryCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCategoryCOValidatePropertiesPOST = function apiV1EnvironmentCOCategoryCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CategoryCO.apiV1EnvironmentCOCategoryCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
