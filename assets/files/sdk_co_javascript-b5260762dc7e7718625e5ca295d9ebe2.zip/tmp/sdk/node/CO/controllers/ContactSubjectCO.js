'use strict';

var utils = require('../utils/writer.js');
var ContactSubjectCO = require('../service/ContactSubjectCOService');

module.exports.apiV1EnvironmentCOContactSubjectCOGET = function apiV1EnvironmentCOContactSubjectCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOIdDELETE = function apiV1EnvironmentCOContactSubjectCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOIdGET = function apiV1EnvironmentCOContactSubjectCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOIdPATCH = function apiV1EnvironmentCOContactSubjectCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOIdPUT = function apiV1EnvironmentCOContactSubjectCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOPOST = function apiV1EnvironmentCOContactSubjectCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOValidatePOST = function apiV1EnvironmentCOContactSubjectCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactSubjectCOValidatePropertiesPOST = function apiV1EnvironmentCOContactSubjectCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactSubjectCO.apiV1EnvironmentCOContactSubjectCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
