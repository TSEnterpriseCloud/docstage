'use strict';

var utils = require('../utils/writer.js');
var AccountingReasonCodeCO = require('../service/AccountingReasonCodeCOService');

module.exports.apiV1EnvironmentCOAccountingReasonCodeCOGET = function apiV1EnvironmentCOAccountingReasonCodeCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AccountingReasonCodeCO.apiV1EnvironmentCOAccountingReasonCodeCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAccountingReasonCodeCOIdGET = function apiV1EnvironmentCOAccountingReasonCodeCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AccountingReasonCodeCO.apiV1EnvironmentCOAccountingReasonCodeCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAccountingReasonCodeCOValidatePOST = function apiV1EnvironmentCOAccountingReasonCodeCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AccountingReasonCodeCO.apiV1EnvironmentCOAccountingReasonCodeCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPOST = function apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AccountingReasonCodeCO.apiV1EnvironmentCOAccountingReasonCodeCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
