'use strict';

var utils = require('../utils/writer.js');
var PgmExec = require('../service/PgmExecService');

module.exports.apiV1EnvironmentCOPgmExecPgmexecschedulerasyncPOST = function apiV1EnvironmentCOPgmExecPgmexecschedulerasyncPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  PgmExec.apiV1EnvironmentCOPgmExecPgmexecschedulerasyncPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
