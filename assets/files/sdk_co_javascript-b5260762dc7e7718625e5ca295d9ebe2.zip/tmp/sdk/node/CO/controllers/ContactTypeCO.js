'use strict';

var utils = require('../utils/writer.js');
var ContactTypeCO = require('../service/ContactTypeCOService');

module.exports.apiV1EnvironmentCOContactTypeCOGET = function apiV1EnvironmentCOContactTypeCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOIdDELETE = function apiV1EnvironmentCOContactTypeCOIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOIdGET = function apiV1EnvironmentCOContactTypeCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOIdPATCH = function apiV1EnvironmentCOContactTypeCOIdPATCH (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOIdPATCH(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOIdPUT = function apiV1EnvironmentCOContactTypeCOIdPUT (req, res, next, body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOIdPUT(body, force, _op, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOPOST = function apiV1EnvironmentCOContactTypeCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOValidatePOST = function apiV1EnvironmentCOContactTypeCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOContactTypeCOValidatePropertiesPOST = function apiV1EnvironmentCOContactTypeCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  ContactTypeCO.apiV1EnvironmentCOContactTypeCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
