'use strict';

var utils = require('../utils/writer.js');
var MacroAreaCO = require('../service/MacroAreaCOService');

module.exports.apiV1EnvironmentCOMacroAreaCOGET = function apiV1EnvironmentCOMacroAreaCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOIdDELETE = function apiV1EnvironmentCOMacroAreaCOIdDELETE (req, res, next, id, environment, tipocf, authorizationScope, company, user, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOIdDELETE(id, environment, tipocf, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOIdGET = function apiV1EnvironmentCOMacroAreaCOIdGET (req, res, next, id, environment, tipocf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOIdGET(id, environment, tipocf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOIdPATCH = function apiV1EnvironmentCOMacroAreaCOIdPATCH (req, res, next, body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOIdPATCH(body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOIdPUT = function apiV1EnvironmentCOMacroAreaCOIdPUT (req, res, next, body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOIdPUT(body, force, _op, tipocf, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOPOST = function apiV1EnvironmentCOMacroAreaCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOValidatePOST = function apiV1EnvironmentCOMacroAreaCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOMacroAreaCOValidatePropertiesPOST = function apiV1EnvironmentCOMacroAreaCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  MacroAreaCO.apiV1EnvironmentCOMacroAreaCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
