'use strict';

var utils = require('../utils/writer.js');
var AreaCO = require('../service/AreaCOService');

module.exports.apiV1EnvironmentCOAreaCOGET = function apiV1EnvironmentCOAreaCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOIdDELETE = function apiV1EnvironmentCOAreaCOIdDELETE (req, res, next, id, environment, macroareaMg07, tipocfMg07, authorizationScope, company, user, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOIdDELETE(id, environment, macroareaMg07, tipocfMg07, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOIdGET = function apiV1EnvironmentCOAreaCOIdGET (req, res, next, id, environment, macroareaMg07, tipocfMg07, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOIdGET(id, environment, macroareaMg07, tipocfMg07, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOIdPATCH = function apiV1EnvironmentCOAreaCOIdPATCH (req, res, next, body, force, _op, macroareaMg07, tipocfMg07, company, user, id, environment, authorizationScope, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOIdPATCH(body, force, _op, macroareaMg07, tipocfMg07, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOIdPUT = function apiV1EnvironmentCOAreaCOIdPUT (req, res, next, body, force, _op, macroareaMg07, tipocfMg07, company, user, id, environment, authorizationScope, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOIdPUT(body, force, _op, macroareaMg07, tipocfMg07, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOPOST = function apiV1EnvironmentCOAreaCOPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOValidatePOST = function apiV1EnvironmentCOAreaCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOAreaCOValidatePropertiesPOST = function apiV1EnvironmentCOAreaCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  AreaCO.apiV1EnvironmentCOAreaCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
