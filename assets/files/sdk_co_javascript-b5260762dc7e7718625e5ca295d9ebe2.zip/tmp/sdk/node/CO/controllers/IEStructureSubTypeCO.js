'use strict';

var utils = require('../utils/writer.js');
var IEStructureSubTypeCO = require('../service/IEStructureSubTypeCOService');

module.exports.apiV1EnvironmentCOIEStructureSubTypeCOIdGET = function apiV1EnvironmentCOIEStructureSubTypeCOIdGET (req, res, next, id, environment, codStructureType, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  IEStructureSubTypeCO.apiV1EnvironmentCOIEStructureSubTypeCOIdGET(id, environment, codStructureType, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
