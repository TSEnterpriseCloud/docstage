'use strict';

var utils = require('../utils/writer.js');
var ProvinceCO = require('../service/ProvinceCOService');

module.exports.apiV1EnvironmentCOProvinceCOIdGET = function apiV1EnvironmentCOProvinceCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  ProvinceCO.apiV1EnvironmentCOProvinceCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
