'use strict';

var utils = require('../utils/writer.js');
var CompanyBankCO = require('../service/CompanyBankCOService');

module.exports.apiV1EnvironmentCOCompanyBankCOGET = function apiV1EnvironmentCOCompanyBankCOGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CompanyBankCO.apiV1EnvironmentCOCompanyBankCOGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCompanyBankCOIdGET = function apiV1EnvironmentCOCompanyBankCOIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CompanyBankCO.apiV1EnvironmentCOCompanyBankCOIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCompanyBankCOValidatePOST = function apiV1EnvironmentCOCompanyBankCOValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CompanyBankCO.apiV1EnvironmentCOCompanyBankCOValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentCOCompanyBankCOValidatePropertiesPOST = function apiV1EnvironmentCOCompanyBankCOValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CompanyBankCO.apiV1EnvironmentCOCompanyBankCOValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
