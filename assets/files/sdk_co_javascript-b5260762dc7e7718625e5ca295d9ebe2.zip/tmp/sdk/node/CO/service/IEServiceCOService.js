'use strict';


/**
 * Get by Guid Session result of import/export
 * Get by Guid Session result of import/export
 *
 * guidProcess String Guid to get the process import/export
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns ImportExportResultDTO
 **/
exports.apiV1EnvironmentCOIEServiceCOGuidProcessGET = function(guidProcess,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "streamFileExport" : "streamFileExport",
  "headProcess" : {
    "guidResult" : "guidResult",
    "totRowImpExp" : 6,
    "impExpWithErrors" : true,
    "rowElab" : [ {
      "isImportance" : true,
      "isError" : true,
      "isWarning" : true,
      "isCreate" : true,
      "isDelete" : true,
      "description" : "description",
      "isInformation" : true,
      "typeResultDescription" : "typeResultDescription",
      "typeResult" : 1,
      "isDone" : true,
      "isUpdate" : true
    }, {
      "isImportance" : true,
      "isError" : true,
      "isWarning" : true,
      "isCreate" : true,
      "isDelete" : true,
      "description" : "description",
      "isInformation" : true,
      "typeResultDescription" : "typeResultDescription",
      "typeResult" : 1,
      "isDone" : true,
      "isUpdate" : true
    } ]
  },
  "guidSession" : "guidSession",
  "idStateProcess" : 0,
  "stateProcess" : "stateProcess"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

