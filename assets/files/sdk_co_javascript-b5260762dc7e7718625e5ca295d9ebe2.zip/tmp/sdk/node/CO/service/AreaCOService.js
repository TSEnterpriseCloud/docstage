'use strict';


/**
 * Get new
 * Get an empty object of type corresponding
 *
 * _op String The value must be 'new'
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns AreaCODTO
 **/
exports.apiV1EnvironmentCOAreaCOGET = function(_op,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "codiceAreaMG" : "codiceAreaMG",
  "macroareaMg07" : "macroareaMg07",
  "dittaCg18" : 0.8008281904610115,
  "zone" : [ {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  }, {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  } ],
  "idprov" : 6,
  "tipocfMg07" : 1.4658129805029452,
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "descrarea" : "descrarea",
  "extensionData" : [ null, null ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * macroareaMg07 String MacroareaMg07 Mandatory to execute current action
 * tipocfMg07 String TipocfMg07 Mandatory to execute current action
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOAreaCOIdDELETE = function(id,environment,macroareaMg07,tipocfMg07,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get by ID
 * Get an object of type corresponding the requested id
 *
 * id String Id to get the object
 * environment String 
 * macroareaMg07 String MacroareaMg07 Mandatory to execute current action
 * tipocfMg07 String TipocfMg07 Mandatory to execute current action
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns AreaCODTO
 **/
exports.apiV1EnvironmentCOAreaCOIdGET = function(id,environment,macroareaMg07,tipocfMg07,authorizationScope,dlevel,dlevelkey,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "codiceAreaMG" : "codiceAreaMG",
  "macroareaMg07" : "macroareaMg07",
  "dittaCg18" : 0.8008281904610115,
  "zone" : [ {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  }, {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  } ],
  "idprov" : 6,
  "tipocfMg07" : 1.4658129805029452,
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "descrarea" : "descrarea",
  "extensionData" : [ null, null ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update partial
 * Patching an object of type
 *
 * body  Object of type to patch
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request (optional)
 * macroareaMg07 String MacroareaMg07 Mandatory to execute current action
 * tipocfMg07 String TipocfMg07 Mandatory to execute current action
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOAreaCOIdPATCH = function(body,force,_op,macroareaMg07,tipocfMg07,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update
 * Updating an object of type
 *
 * body AreaCODTO Object of type to update
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional)
 * macroareaMg07 String MacroareaMg07 Mandatory to execute current action
 * tipocfMg07 String TipocfMg07 Mandatory to execute current action
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AreaCODTO
 **/
exports.apiV1EnvironmentCOAreaCOIdPUT = function(body,force,_op,macroareaMg07,tipocfMg07,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "codiceAreaMG" : "codiceAreaMG",
  "macroareaMg07" : "macroareaMg07",
  "dittaCg18" : 0.8008281904610115,
  "zone" : [ {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  }, {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  } ],
  "idprov" : 6,
  "tipocfMg07" : 1.4658129805029452,
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "descrarea" : "descrarea",
  "extensionData" : [ null, null ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create
 * Creating new object of type
 *
 * body AreaCODTO Object of type to create
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns AreaCODTO
 **/
exports.apiV1EnvironmentCOAreaCOPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "codiceAreaMG" : "codiceAreaMG",
  "macroareaMg07" : "macroareaMg07",
  "dittaCg18" : 0.8008281904610115,
  "zone" : [ {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  }, {
    "areaMg08" : "areaMg08",
    "macroareaMg08" : "macroareaMg08",
    "dittaCg18" : 5.962133916683182,
    "idprov" : 5,
    "descrzona" : "descrzona",
    "tipocfMg08" : 2.3021358869347655,
    "pluginData" : {
      "key" : ""
    },
    "codiceZona" : "codiceZona",
    "additionalData" : {
      "key" : ""
    },
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  } ],
  "idprov" : 6,
  "tipocfMg07" : 1.4658129805029452,
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "descrarea" : "descrarea",
  "extensionData" : [ null, null ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Validate
 * Validation of object of type
 *
 * body AreaCODTO Object of type to validate
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOAreaCOValidatePOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Validation of one on more properties of Type
 * Validation of object of type
 *
 * body String  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ValidateDTO
 **/
exports.apiV1EnvironmentCOAreaCOValidatePropertiesPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "items" : [ {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  }, {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  } ],
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

