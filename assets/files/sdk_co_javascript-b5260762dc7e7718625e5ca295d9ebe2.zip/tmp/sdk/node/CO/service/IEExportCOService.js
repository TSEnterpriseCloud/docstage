'use strict';


/**
 * Export Customers/Suppliers based on the required parameters
 * Export Customers/Suppliers based on the required parameters
 *
 * body ExportCustomerSupplierCOParameterDTO Export Customers/Suppliers parameters
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ImportExportResultDTO
 **/
exports.apiV1EnvironmentCOIEExportCOCustomersupplierPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "streamFileExport" : "streamFileExport",
  "headProcess" : {
    "guidResult" : "guidResult",
    "totRowImpExp" : 6,
    "impExpWithErrors" : true,
    "rowElab" : [ {
      "isImportance" : true,
      "isError" : true,
      "isWarning" : true,
      "isCreate" : true,
      "isDelete" : true,
      "description" : "description",
      "isInformation" : true,
      "typeResultDescription" : "typeResultDescription",
      "typeResult" : 1,
      "isDone" : true,
      "isUpdate" : true
    }, {
      "isImportance" : true,
      "isError" : true,
      "isWarning" : true,
      "isCreate" : true,
      "isDelete" : true,
      "description" : "description",
      "isInformation" : true,
      "typeResultDescription" : "typeResultDescription",
      "typeResult" : 1,
      "isDone" : true,
      "isUpdate" : true
    } ]
  },
  "guidSession" : "guidSession",
  "idStateProcess" : 0,
  "stateProcess" : "stateProcess"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

