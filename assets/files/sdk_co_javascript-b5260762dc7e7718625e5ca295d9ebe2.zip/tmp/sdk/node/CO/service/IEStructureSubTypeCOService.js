'use strict';


/**
 * Get by ID
 * Get an object of type corresponding the requested id
 *
 * id String Id to get the object
 * environment String 
 * codStructureType String CodStructureType Mandatory to execute current action
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns IEStructureSubTypeCODTO
 **/
exports.apiV1EnvironmentCOIEStructureSubTypeCOIdGET = function(id,environment,codStructureType,authorizationScope,dlevel,dlevelkey,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "codStructureSubType" : 1.2315135367772556,
  "structureType" : {
    "classExport" : "classExport",
    "typeProcedure" : 4.965218492984954,
    "typeImpExp" : 1.1730742509559433,
    "sortingEnabledFlag" : 7.457744773683766,
    "classImport" : "classImport",
    "description" : "description",
    "pluginData" : {
      "key" : ""
    },
    "additionalData" : {
      "key" : ""
    },
    "codStructureType" : 1,
    "excludeFlag" : 6.84685269835264,
    "extensionData" : [ {
      "value" : "",
      "key" : "key"
    }, {
      "value" : "",
      "key" : "key"
    } ]
  },
  "description" : "description",
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "codStructureType" : 1,
  "extensionData" : [ null, null ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

