'use strict';


/**
 * Get new
 * Get an empty object of type corresponding
 *
 * _op String The value must be 'new'
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns ContactSubjectCODTO
 **/
exports.apiV1EnvironmentCOContactSubjectCOGET = function(_op,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "note" : "note",
  "cognomenome" : "cognomenome",
  "idmediaCg99" : 2.3021358869347655,
  "indirizzo" : "indirizzo",
  "telcasa" : "telcasa",
  "pec" : "pec",
  "email2" : "email2",
  "email1" : "email1",
  "teldir1" : "teldir1",
  "cap" : "cap",
  "orariolav" : "orariolav",
  "pluginData" : {
    "key" : ""
  },
  "id" : 5.637376656633329,
  "additionalData" : {
    "key" : ""
  },
  "fax" : "fax",
  "prov" : "prov",
  "citta" : "citta",
  "altro2" : "altro2",
  "altro1" : "altro1",
  "cell1" : "cell1",
  "teldir2" : "teldir2",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "cell2" : "cell2",
  "guid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastchange" : "2000-01-23T04:56:07.000+00:00",
  "indPrefstdoc" : 7.061401241503109,
  "rowversion" : ""
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Delete
 * Deleting object of type 
 *
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOContactSubjectCOIdDELETE = function(id,environment,authorizationScope,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get by ID
 * Get an object of type corresponding the requested id
 *
 * id String Id to get the object
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * dlevel String Serialization level (optional)
 * dlevelkey String Serialization level key (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * acceptLanguage String Example for multilanguage (optional)
 * returns ContactSubjectCODTO
 **/
exports.apiV1EnvironmentCOContactSubjectCOIdGET = function(id,environment,authorizationScope,dlevel,dlevelkey,company,user,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "note" : "note",
  "cognomenome" : "cognomenome",
  "idmediaCg99" : 2.3021358869347655,
  "indirizzo" : "indirizzo",
  "telcasa" : "telcasa",
  "pec" : "pec",
  "email2" : "email2",
  "email1" : "email1",
  "teldir1" : "teldir1",
  "cap" : "cap",
  "orariolav" : "orariolav",
  "pluginData" : {
    "key" : ""
  },
  "id" : 5.637376656633329,
  "additionalData" : {
    "key" : ""
  },
  "fax" : "fax",
  "prov" : "prov",
  "citta" : "citta",
  "altro2" : "altro2",
  "altro1" : "altro1",
  "cell1" : "cell1",
  "teldir2" : "teldir2",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "cell2" : "cell2",
  "guid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastchange" : "2000-01-23T04:56:07.000+00:00",
  "indPrefstdoc" : 7.061401241503109,
  "rowversion" : ""
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Update partial
 * Patching an object of type
 *
 * body  Object of type to patch
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOContactSubjectCOIdPATCH = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Update
 * Updating an object of type
 *
 * body ContactSubjectCODTO Object of type to update
 * force String The warning/s code to bypass (separated by ‘,’) during the execution (optional)
 * _op String Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * id String 
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ContactSubjectCODTO
 **/
exports.apiV1EnvironmentCOContactSubjectCOIdPUT = function(body,force,_op,company,user,id,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "note" : "note",
  "cognomenome" : "cognomenome",
  "idmediaCg99" : 2.3021358869347655,
  "indirizzo" : "indirizzo",
  "telcasa" : "telcasa",
  "pec" : "pec",
  "email2" : "email2",
  "email1" : "email1",
  "teldir1" : "teldir1",
  "cap" : "cap",
  "orariolav" : "orariolav",
  "pluginData" : {
    "key" : ""
  },
  "id" : 5.637376656633329,
  "additionalData" : {
    "key" : ""
  },
  "fax" : "fax",
  "prov" : "prov",
  "citta" : "citta",
  "altro2" : "altro2",
  "altro1" : "altro1",
  "cell1" : "cell1",
  "teldir2" : "teldir2",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "cell2" : "cell2",
  "guid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastchange" : "2000-01-23T04:56:07.000+00:00",
  "indPrefstdoc" : 7.061401241503109,
  "rowversion" : ""
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create
 * Creating new object of type
 *
 * body ContactSubjectCODTO Object of type to create
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ContactSubjectCODTO
 **/
exports.apiV1EnvironmentCOContactSubjectCOPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "note" : "note",
  "cognomenome" : "cognomenome",
  "idmediaCg99" : 2.3021358869347655,
  "indirizzo" : "indirizzo",
  "telcasa" : "telcasa",
  "pec" : "pec",
  "email2" : "email2",
  "email1" : "email1",
  "teldir1" : "teldir1",
  "cap" : "cap",
  "orariolav" : "orariolav",
  "pluginData" : {
    "key" : ""
  },
  "id" : 5.637376656633329,
  "additionalData" : {
    "key" : ""
  },
  "fax" : "fax",
  "prov" : "prov",
  "citta" : "citta",
  "altro2" : "altro2",
  "altro1" : "altro1",
  "cell1" : "cell1",
  "teldir2" : "teldir2",
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ],
  "cell2" : "cell2",
  "guid" : "046b6c7f-0b8a-43b9-b35d-6489e6daee91",
  "lastchange" : "2000-01-23T04:56:07.000+00:00",
  "indPrefstdoc" : 7.061401241503109,
  "rowversion" : ""
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Validate
 * Validation of object of type
 *
 * body ContactSubjectCODTO Object of type to validate
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * no response value expected for this operation
 **/
exports.apiV1EnvironmentCOContactSubjectCOValidatePOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Validation of one on more properties of Type
 * Validation of object of type
 *
 * body String  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns ValidateDTO
 **/
exports.apiV1EnvironmentCOContactSubjectCOValidatePropertiesPOST = function(body,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "pluginData" : {
    "key" : ""
  },
  "additionalData" : {
    "key" : ""
  },
  "items" : [ {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  }, {
    "isError" : true,
    "isWarning" : true,
    "warningCode" : 0,
    "dtoName" : "dtoName",
    "dtoPropertyName" : "dtoPropertyName",
    "message" : "message",
    "entityPropertyPath" : "entityPropertyPath"
  } ],
  "extensionData" : [ {
    "value" : "",
    "key" : "key"
  }, {
    "value" : "",
    "key" : "key"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

