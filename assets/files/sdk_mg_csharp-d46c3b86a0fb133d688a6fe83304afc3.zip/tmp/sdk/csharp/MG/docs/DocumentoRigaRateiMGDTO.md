# IO.Swagger.Model.DocumentoRigaRateiMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adatacomp** | **DateTime?** | DO42_ADATACOMP - A data competenza | [optional] 
**CodBeneusato** | **double?** | DO42_CODBENEUSATO - Codice bene usato | [optional] 
**ContoparCg24** | **string** | DO42_CONTOPAR_CG24 - Conto contropartita | [optional] 
**Dadatacomp** | **DateTime?** | DO42_DADATACOMP - Da data competenza | [optional] 
**Dataregesinc** | **DateTime?** | DO42_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**Dataregesprec** | **DateTime?** | DO42_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**DittaCg18** | **double?** | DO42_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**FlgDaav** | **double?** | DO42_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0]
**FlgDisatcoge** | **double?** | DO42_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0]
**Importo** | **double?** | DO42_IMPORTO - Importo | [optional] 
**Imprettcostobu** | **double?** | DO42_IMPRETTCOSTOBU - Imprettcostobu | [optional] 
**ImprettcostobuVal** | **double?** | DO42_IMPRETTCOSTOBU_VAL - ImprettcostobuVal | [optional] 
**IndTipocomp** | **double?** | DO42_INDTIPOCOMP - Importo | [optional] [default to 0]
**IndTipomovbu** | **double?** | DO42_INDTIPOMOVBU - IndTipomovbu | [optional] [default to 0]
**Percforf** | **double?** | DO42_PERCFORF - Percforf | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

