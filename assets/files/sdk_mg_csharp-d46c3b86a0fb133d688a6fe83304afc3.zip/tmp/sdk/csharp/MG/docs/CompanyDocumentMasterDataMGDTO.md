# IO.Swagger.Model.CompanyDocumentMasterDataMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodDocumMg36** | **string** | MG3G_CODDOCUM_MG36 - Codice documento | 
**DittaCg18** | **double?** | MG3G_DITTA_CG18 - Ditta | [optional] [default to 0]
**IndStaperMg36** | **double?** | MG3G_INDSTAPER_MG36 - Indicatore standard/personalizzato&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Standard&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Personalizzato&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**Sezdefault** | **string** | MG3G_SEZDEFAULT - Sezionale default | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

