# IO.Swagger.Model.COAAccountStateFIDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConsosCg24** | **string** | CG0S_CONSOS_CG24 - Non utilizzato | [optional] 
**DittaCg18** | **double?** | CG0S_DITTA_CG18 - Ditta | 
**Dtconsos** | **DateTime?** | CG0S_DTCONSOS - Non utilizzato | [optional] 
**Dtdisatt** | **DateTime?** | CG0S_DTDISATT - Data di disattivazione | [optional] 
**FlgDisatt** | **double?** | CG0S_FLGDISATT - Conto disattivato | 
**GrusosCg10** | **double?** | CG0S_GRUSOS_CG10 - Non utilizzato | [optional] 
**IdCg24** | **long?** | CG0S_ID_CG24 - ID Conto | 
**Idstatipdc** | **long?** | CG0S_IDSTATIPDC - ID (Required only in PUT/PATCH) | [optional] 
**Rowversion** | **byte[]** | CG0S_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

