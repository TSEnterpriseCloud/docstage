# IO.Swagger.Model.DocumentoTestataOrdiniMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datacons** | **DateTime?** | DO18_DATACONS - Data consegna | [optional] 
**Dataconsint** | **DateTime?** | DO18_DATACONSINT - Data consegna interna | [optional] 
**Dataconsorig** | **DateTime?** | DO18_DATACONSORIG - Data consegna origine | [optional] 
**DittaCg18** | **double?** | DO18_DITTA_CG18 - Ditta | [optional] [default to 0]
**FlgConfrit** | **int?** | DO18_FLGCONFRIT - Flag conferma ritornata&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgEvastot** | **int?** | DO18_FLGEVASTOT - Flag evasione totale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNoevasparz** | **int?** | DO18_FLGNOEVASPARZ - Flag no evasione parziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNonann** | **int?** | DO18_FLGNONANN - Flag da non annullare&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgNonpiuev** | **int?** | DO18_FLGNONPIUEV - Flag ordine non più evadibile&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**FlgRicpreev** | **int?** | DO18_FLGRICPREEV - Flag ricalcolo prezzi in evasione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Ggtollercons** | **double?** | DO18_GGTOLLERCONS - Giorni di tolleranza consegna | [optional] 
**NumregCo99** | **string** | DO18_NUMREG_CO99 - Numero registrazione | 
**Priorita** | **double?** | DO18_PRIORITA - Priorità | [optional] [default to 0]
**Tipoinoltro** | **double?** | DO18_TIPOINOLTRO - Tipo inoltro | [optional] [default to 0]
**Tipoordine** | **double?** | DO18_TIPOORDINE - Tipo ordine | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

