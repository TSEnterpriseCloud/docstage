# IO.Swagger.Model.KitDocumentResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NumRegLoadProductKit** | **List&lt;string&gt;** | List of serial numbers created for component unloading documents | [optional] 
**NumRegUnloadComp** | **List&lt;string&gt;** | List of serial numbers created for kit product loading documents | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

