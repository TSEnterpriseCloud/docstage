# IO.Swagger.Model.UnloadComponentKitParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentCode** | **string** | Document code for uploading component kit | 
**PostingDate** | **DateTime?** | Document posting date | [optional] 
**DocumentDate** | **DateTime?** | Document date | [optional] 
**DocumentSectional** | **string** | Document sectional | [optional] 
**DocumentNumber** | **double?** | Document number | [optional] 
**StorageCode** | **string** | Storage code | [optional] 
**IndExplosionLevel** | **string** | Explosion level type&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 - All levels&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 - Up to level&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 - Up to 1st level&lt;/li&gt;&lt;/ul&gt; | [optional] [default to "0"]
**NumberLevel** | **int?** | Number level if explosion level type is up to level  | [optional] [default to 1]
**IndSemiFinishedProducts** | **string** | Semi-finished goods handling type&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 - Unload only&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 - Load and unload&lt;/li&gt;&lt;/ul&gt; | [optional] [default to "0"]
**RecalculateCostKitProduct** | **bool?** | Recalculation of the cost of Kit products | [optional] [default to false]
**IncludeBOMComponents** | **bool?** | Also include the BOM components (1st level) in the download | [optional] [default to false]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

