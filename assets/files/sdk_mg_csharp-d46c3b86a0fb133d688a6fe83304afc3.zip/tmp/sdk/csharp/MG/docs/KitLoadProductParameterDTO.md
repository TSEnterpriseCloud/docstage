# IO.Swagger.Model.KitLoadProductParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LoadProductKitParameter** | [**LoadProductKitParameterDTO**](LoadProductKitParameterDTO.md) |  | 
**UnloadComponentKitParameter** | [**UnloadComponentKitParameterDTO**](UnloadComponentKitParameterDTO.md) |  | [optional] 
**HeadUnloadDocumentsFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**RowUnloadDocumentsFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

