# IO.Swagger.Model.DocumentMasterCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datacre** | **DateTime?** | CO99_DATACRE - Data creazione | [optional] 
**Datavar** | **DateTime?** | CO99_DATAVAR - Data ultima variazione | [optional] 
**Descnote1** | **string** | CO99_DESCNOTE1 - Note | [optional] 
**DittaCg18** | **double?** | CO99_DITTA_CG18 - Ditta | [optional] [default to 0]
**Gruppocre** | **string** | CO99_GRUPPOCRE - Gruppo utente creazione | [optional] 
**Gruppovar** | **string** | CO99_GRUPPOVAR - Gruppo variazione | [optional] 
**IndTipoop** | **double?** | CO99_INDTIPOOP - Indicatore tipo operazione | [optional] [default to 0]
**Numreg** | **string** | CO99_NUMREG - Numero registrazione | 
**Utentecre** | **string** | CO99_UTENTECRE - Utente creazione | [optional] 
**Utentevar** | **string** | CO99_UTENTEVAR - Utente variazione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

