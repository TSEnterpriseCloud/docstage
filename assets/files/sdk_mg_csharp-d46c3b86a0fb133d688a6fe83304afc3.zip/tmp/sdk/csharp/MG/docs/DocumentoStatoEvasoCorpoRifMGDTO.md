# IO.Swagger.Model.DocumentoStatoEvasoCorpoRifMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DittaDo33Cg18** | **double?** | VFW_DITTA_DO33_CG18 - DittaDo33Cg18 | 
**IdDo33** | **long?** | VFW_ID_DO33 - IdDo33 (Required only in PUT/PATCH) | [optional] 
**IdDo33Do30** | **long?** | VFW_ID_DO33_DO30 - IdDo33Do30 | 
**IdrifDo33Do30** | **long?** | VFW_IDRIF_DO33_DO30 - IdrifDo33Do30 | 
**NumregDo33Co99** | **string** | VFW_NUMREG_DO33_CO99 - NumregDo33Co99 | 
**NumregrifCo99Do33Do30** | **string** | VFW_NUMREGRIF_CO99_DO33_DO30 - NumregrifCo99Do33Do30 | [optional] 
**ProgRigaDo33** | **double?** | VFW_PROGRIGA_DO33 - ProgRigaDo33 | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

