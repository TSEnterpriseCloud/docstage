# IO.Swagger.Model.LotMovParameterWHDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DittaCg18** | **double?** | MG4F_DITTA_CG18 - Ditta | [optional] [default to 0]
**FlgAggprogval** | **double?** | MG4F_FLGAGGPROGVAL - Gestione progressivi di magazzino a valore | [optional] [default to 0]
**FlgNote** | **double?** | MG4F_FLGNOTE - Gestione note | [optional] [default to 0]
**IndGiacsca** | **double?** | MG4F_INDGIACSCA - Indicatore scarichi con giacenza negativa&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Non gestito&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Segnala se in scarico la giacenza è negativa (senza blocco)&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Blocco se in scarico la giacenza è negativa&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Prog** | **double?** | MG4F_PROG - Progressivo | 
**Tipomov** | **string** | MG4F_TIPOMOV - Tipo movimento | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

