# IO.Swagger.Model.DocumentoRigaIntraMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Annorif** | **double?** | DO68_ANNORIF - Anno di riferimento | [optional] 
**CodiceCg72** | **string** | DO68_CODICE_CG72 - Codice Nomenclatura / Servizio | [optional] 
**DittaCg18** | **double?** | DO68_DITTA_CG18 - Ditta | 
**Fatconvumsuppl** | **double?** | DO68_FATCONVUMSUPPL - Fatt. conv. U.M. suppl. | [optional] 
**FlgEsclintra** | **double?** | DO68_FLGESCLINTRA - Escludi da operazioni Intra | [optional] [default to 0]
**IndTipoCg72** | **double?** | DO68_INDTIPO_CG72 - Tipologia Intra&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Bene&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Servizio&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Massanetta** | **double?** | DO68_MASSANETTA - Massa netta | [optional] 
**Meserif** | **double?** | DO68_MESERIF - Mese di riferimento | [optional] 
**ModerogazioneIn03** | **string** | DO68_MODEROGAZIONE_IN03 - Modalità di erogazione | [optional] 
**ModincassoIn04** | **string** | DO68_MODINCASSO_IN04 - Modalità di incasso | [optional] 
**NumregCo99** | **string** | DO68_NUMREG_CO99 - Numero registrazione | 
**PaesedestCg07** | **double?** | DO68_PAESEDEST_CG07 - Paese di destinazione | [optional] 
**PaeseorigCg07** | **double?** | DO68_PAESEORIG_CG07 - Paese di origine | [optional] 
**PaesepagCg07** | **double?** | DO68_PAESEPAG_CG07 - Paese di pagamento | [optional] 
**PaeseprovCg07** | **double?** | DO68_PAESEPROV_CG07 - Paese di provenienza | [optional] 
**Percadegvalstat** | **double?** | DO68_PERCADEGVALSTAT - % adeguamento valore statistico | [optional] 
**ProgRiga** | **double?** | DO68_PROGRIGA - Progressivo Riga | 
**Provdest** | **string** | DO68_PROVDEST - Provincia destinazione | [optional] 
**Provorig** | **string** | DO68_PROVORIG - Provincia di origine | [optional] 
**Unsuppl** | **double?** | DO68_UNSUPPL - UM supplementare | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

