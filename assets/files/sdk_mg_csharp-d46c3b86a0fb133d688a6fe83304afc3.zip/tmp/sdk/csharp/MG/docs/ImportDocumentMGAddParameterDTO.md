# IO.Swagger.Model.ImportDocumentMGAddParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentCode** | **string** | Document code to use for import | [optional] 
**SelectionActionDocumentExist** | **string** | Select the Action to undertake if document exists&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 - Do not update &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 - Delete document &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 2 - Delete and import &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 3 - Update header, add body lines &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 4 - Insert with same number &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 5 - Insert with new number &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 6 - Update header, change body lines &lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 7 - Update header, update body &lt;/li&gt;&lt;/ul&gt; | [optional] [default to "4"]
**InsertNewCustomerSupplier** | **bool?** | Inserting new Customers/Suppliers | [optional] [default to true]
**UpdateExistingCustomerSupplier** | **bool?** | Update existing Customers/Suppliers | [optional] [default to false]
**InsertNewItem** | **bool?** | Inserting new Items | [optional] [default to true]
**UpdateExistingItem** | **bool?** | Update existing Items | [optional] [default to false]
**InsertDataForNotExistingTables** | **bool?** | Inserts data for AgencyCO, CarrierMG, RecipientMG, PaymentTermCO, AgentMG, FamilyWH/SubFamilyWH, ItemGroupWH/ItemSubGroupWH if not present in the archive | [optional] [default to true]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

