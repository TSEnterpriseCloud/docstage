# IO.Swagger.Model.DocumentoTestataProgettiMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CausmgoMgfo** | **int?** | DO24_CAUSMGO_MGFO - CausmgoMgfo | [optional] 
**CodCommessa** | **string** | DO24_CODCOMMESSA - Codice commessa | [optional] 
**CodDipPd06** | **string** | DO24_CODDIP_PD06 - Codice dipendente | [optional] 
**CodProgcol** | **string** | DO24_CODPROGCOL - Codice progetto collegato | [optional] 
**CodProgetto** | **string** | DO24_CODPROGETTO - Codice progetto | [optional] 
**CodScommessa** | **double?** | DO24_CODSCOMMESSA - Codice sottocommessa | [optional] 
**CodSprogcol** | **double?** | DO24_CODSPROGCOL - Codice sottoprogetto collegato | [optional] 
**CodSprogetto** | **double?** | DO24_CODSPROGETTO - Codice sottoprogetto | [optional] 
**DittaCg18** | **double?** | DO24_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**NodorifcolPd0c** | **string** | DO24_NODORIFCOL_PD0C - Codice nodo di riferimento collegato | [optional] 
**NodorifPd0c** | **string** | DO24_NODORIF_PD0C - Codice Nodo di riferimento | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

