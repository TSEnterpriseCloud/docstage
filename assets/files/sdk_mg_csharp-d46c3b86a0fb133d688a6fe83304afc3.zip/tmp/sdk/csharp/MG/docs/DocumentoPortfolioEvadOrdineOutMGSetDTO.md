# IO.Swagger.Model.DocumentoPortfolioEvadOrdineOutMGSetDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidSession** | **string** | Guid Session Result | [optional] 
**Rows** | [**List&lt;DocumPortfolioEvaMGDTO&gt;**](DocumPortfolioEvaMGDTO.md) | ResultSet Rows | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

