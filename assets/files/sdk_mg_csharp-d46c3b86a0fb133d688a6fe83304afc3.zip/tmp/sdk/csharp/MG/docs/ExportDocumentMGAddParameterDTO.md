# IO.Swagger.Model.ExportDocumentMGAddParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SelectDocToExtracted** | **string** | Select items to extract&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - 0 - All&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - 1 - To extract&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - 2 - Estract&lt;/li&gt;&lt;/ul&gt; | [optional] [default to "0"]
**UpdateExtractedDocuments** | **bool?** | Update Extracted Documents | [optional] [default to true]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

