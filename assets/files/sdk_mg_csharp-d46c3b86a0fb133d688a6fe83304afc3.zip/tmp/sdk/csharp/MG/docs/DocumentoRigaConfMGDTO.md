# IO.Swagger.Model.DocumentoRigaConfMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Capacita** | **double?** | DO39_CAPACITA - Capacità | [optional] 
**CodConfezMg96** | **string** | DO39_CODCONFEZ_MG96 - Codice confezione | 
**ColliConf** | **double?** | DO39_COLLICONF - Colli confezione | 
**DittaCg18** | **double?** | DO39_DITTA_CG18 - Ditta | [optional] [default to 0]
**NumregCo99** | **string** | DO39_NUMREG_CO99 - Numero registrazione | 
**PesoLordo** | **double?** | DO39_PESOL - Peso lordo | [optional] 
**PesoNetto** | **double?** | DO39_PESON - Peso netto | [optional] 
**ProgRiga** | **double?** | DO39_PROGRIGA - Progressivo Riga | 
**PzConf** | **double?** | DO39_PZCONF - Pezzi per confezione | 
**Qta1Conf** | **double?** | DO39_QTA1CONF - Qta1 | 
**Qta2Conf** | **double?** | DO39_QTA2CONF - Qta2 | 
**UmCapac** | **string** | DO39_UMCAPAC - UM capacità | [optional] 
**UmPeso** | **string** | DO39_UMPESO - Unità di misura del peso | [optional] 
**UmVolume** | **string** | DO39_UMVOLUME - UM Volume | [optional] 
**Volume** | **double?** | DO39_VOLUME - Volume | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

