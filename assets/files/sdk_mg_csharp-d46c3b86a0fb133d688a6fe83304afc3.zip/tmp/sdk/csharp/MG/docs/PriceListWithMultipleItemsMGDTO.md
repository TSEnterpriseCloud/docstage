# IO.Swagger.Model.PriceListWithMultipleItemsMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | LI26_CODICE - Codice listino con più articoli | 
**Descr** | **string** | LI26_DESCR - Descrizione | [optional] 
**DittaCg18** | **double?** | LI26_DITTA_CG18 - Ditta | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

