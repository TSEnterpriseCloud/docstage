# IO.Swagger.Model.SalePurchasePriceListCodeMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Desclist** | **string** | MG44_DESCLIST - Descrizione listino | 
**DittaCg18** | **double?** | MG44_DITTA_CG18 - Ditta | [optional] [default to 0]
**FlgVenacq** | **double?** | MG44_FLGVENACQ - Vendita / Acquisto&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Listino di vendita&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Listino di acquisto&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Numlist** | **double?** | MG44_NUMLIST - Numero listino | 
**ValutaCg08** | **string** | MG44_VALUTA_CG08 - Codice valuta | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

