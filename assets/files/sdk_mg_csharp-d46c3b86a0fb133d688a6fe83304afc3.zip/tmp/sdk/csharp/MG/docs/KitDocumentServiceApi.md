# IO.Swagger.Api.KitDocumentServiceApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentMGKitDocumentServiceLoadkitPost**](KitDocumentServiceApi.md#apiv1environmentmgkitdocumentserviceloadkitpost) | **POST** /api/v1/{environment}/MG/KitDocumentService/loadkit | Creation of component unloading documents from loading documents based on the required parameters
[**ApiV1EnvironmentMGKitDocumentServiceUnloadcompPost**](KitDocumentServiceApi.md#apiv1environmentmgkitdocumentserviceunloadcomppost) | **POST** /api/v1/{environment}/MG/KitDocumentService/unloadcomp | Creation of component unloading documents from loading documents based on the required parameters

<a name="apiv1environmentmgkitdocumentserviceloadkitpost"></a>
# **ApiV1EnvironmentMGKitDocumentServiceLoadkitPost**
> KitDocumentResultDTO ApiV1EnvironmentMGKitDocumentServiceLoadkitPost (KitLoadProductParameterDTO body, string authorizationScope, string environment, string acceptLanguage = null, string force = null, string company = null, string user = null)

Creation of component unloading documents from loading documents based on the required parameters

Creation of component unloading documents from loading documents based on the required parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentMGKitDocumentServiceLoadkitPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new KitDocumentServiceApi();
            var body = new KitLoadProductParameterDTO(); // KitLoadProductParameterDTO | Creation of component unloading documents parameters
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var force = force_example;  // string | Force values (optional) 
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Creation of component unloading documents from loading documents based on the required parameters
                KitDocumentResultDTO result = apiInstance.ApiV1EnvironmentMGKitDocumentServiceLoadkitPost(body, authorizationScope, environment, acceptLanguage, force, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling KitDocumentServiceApi.ApiV1EnvironmentMGKitDocumentServiceLoadkitPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**KitLoadProductParameterDTO**](KitLoadProductParameterDTO.md)| Creation of component unloading documents parameters | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **force** | **string**| Force values | [optional] 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**KitDocumentResultDTO**](KitDocumentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentmgkitdocumentserviceunloadcomppost"></a>
# **ApiV1EnvironmentMGKitDocumentServiceUnloadcompPost**
> KitDocumentResultDTO ApiV1EnvironmentMGKitDocumentServiceUnloadcompPost (KitUnloadComponentParameterDTO body, string authorizationScope, string environment, string acceptLanguage = null, string force = null, string company = null, string user = null)

Creation of component unloading documents from loading documents based on the required parameters

Creation of component unloading documents from loading documents based on the required parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentMGKitDocumentServiceUnloadcompPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new KitDocumentServiceApi();
            var body = new KitUnloadComponentParameterDTO(); // KitUnloadComponentParameterDTO | Creation of component unloading documents parameters
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var force = force_example;  // string | Force values (optional) 
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Creation of component unloading documents from loading documents based on the required parameters
                KitDocumentResultDTO result = apiInstance.ApiV1EnvironmentMGKitDocumentServiceUnloadcompPost(body, authorizationScope, environment, acceptLanguage, force, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling KitDocumentServiceApi.ApiV1EnvironmentMGKitDocumentServiceUnloadcompPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**KitUnloadComponentParameterDTO**](KitUnloadComponentParameterDTO.md)| Creation of component unloading documents parameters | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **force** | **string**| Force values | [optional] 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**KitDocumentResultDTO**](KitDocumentResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
