# IO.Swagger.Model.DocumentoTestataRateiMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Adatacomp** | **DateTime?** | DO23_ADATACOMP - A data competenza | [optional] 
**Contopar** | **string** | DO23_CONTOPAR - Conto contropartita | [optional] 
**Dadatacomp** | **DateTime?** | DO23_DADATACOMP - Da data competenza | [optional] 
**Datacompivaman** | **DateTime?** | DO23_DATACOMPIVAMAN - Data competenza IVA manuale | [optional] 
**Dataregesinc** | **DateTime?** | DO23_DATAREGESINC - Data registrazione rateo esercizio corrente | [optional] 
**Dataregesprec** | **DateTime?** | DO23_DATAREGESPREC - Data registrazione rateo esercizio precedente | [optional] 
**DittaCg18** | **double?** | DO23_DITTA_CG18 - Codice ditta | [optional] [default to 0]
**FlgDaav** | **double?** | DO23_FLGDAAV - Indicatore Dare/Avere | [optional] [default to 0]
**FlgDisatcoge** | **double?** | DO23_FLGDISATCOGE - FlgDisatcoge | [optional] [default to 0]
**IndTipocomp** | **double?** | DO23_INDTIPOCOMP - Indicatore tipo competenza | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

