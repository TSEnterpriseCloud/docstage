# IO.Swagger.Model.LoadProductKitParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentCode** | **string** | Document code for loading kit products | 
**PostingDate** | **DateTime?** | Document posting date | [optional] 
**DocumentDate** | **DateTime?** | Document date | [optional] 
**DocumentSectional** | **string** | Document sectional | [optional] 
**DocumentNumber** | **double?** | Document number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

