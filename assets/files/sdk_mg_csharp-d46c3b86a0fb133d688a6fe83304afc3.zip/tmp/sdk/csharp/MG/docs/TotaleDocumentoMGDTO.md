# IO.Swagger.Model.TotaleDocumentoMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Totdocumento** | **double?** | DO13_TOTDOCUMENTO - Totale documento - This parameter is for Read Only use !! (Cannot set any value) | 
**Totimponibile** | **double?** | DO13_TOTIMPONIBILE - Totale imponibile - This parameter is for Read Only use !! (Cannot set any value) | 
**Totiva** | **double?** | DO13_TOTIVA - Totale IVA - This parameter is for Read Only use !! (Cannot set any value) | 
**Abbuono** | **double?** | DO13_ABBUONO - Abbuono | [optional] [default to 0]
**Acconto** | **double?** | DO13_ACCONTO - Acconto | [optional] [default to 0]
**Imponibomag** | **double?** | DO13_IMPONIBOMAG - Imponibile omaggi | [optional] [default to 0]
**Ivaomag** | **double?** | DO13_IVAOMAG - Importo IVA omaggi | [optional] [default to 0]
**Marginedocumento** | **double?** | DO13_MARGINEDOCUMENTO - Importo margine totale | 
**Scimpcassa** | **double?** | DO13_SCIMPCASSA - Sconto cassa ad importo | [optional] [default to 0]
**Scimpmerce** | **double?** | DO13_SCIMPMERCE - Sconto merce ad importo | [optional] [default to 0]
**Scpercassa1** | **double?** | DO13_SCPERCASSA1 - Sconto 1 cassa in percentuale | [optional] [default to 0]
**Scpercassa2** | **double?** | DO13_SCPERCASSA2 - Sconto 2 cassa in percentuale | [optional] [default to 0]
**Scpermerce1** | **double?** | DO13_SCPERMERCE1 - Sconto 1 merce in percentuale | [optional] [default to 0]
**Scpermerce2** | **double?** | DO13_SCPERMERCE2 - Sconto 2 merce in percentuale | [optional] [default to 0]
**Scpermerce3** | **double?** | DO13_SCPERMERCE3 - Sconto 3 merce in percentuale | [optional] [default to 0]
**TotaleCosto** | **double?** | DO13_TOTCOSTO - Totale costo | [optional] [default to 0]
**TotalePagare** | **double?** | DO13_TOTAPAGARE - Totale a pagare | 
**Totspbolli** | **double?** | DO13_TOTSPBOLLI - Totale spese bolli | [optional] [default to 0]
**Totspinc** | **double?** | DO13_TOTSPINC - Totale spese incasso | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

