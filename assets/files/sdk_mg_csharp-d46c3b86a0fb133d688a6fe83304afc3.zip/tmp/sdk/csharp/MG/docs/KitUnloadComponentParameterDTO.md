# IO.Swagger.Model.KitUnloadComponentParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LoadDocumentCodeFilter** | **string** | Product Loading Document Code Selection | 
**UnloadComponentKitParameter** | [**UnloadComponentKitParameterDTO**](UnloadComponentKitParameterDTO.md) |  | 
**HeadLoadDocumentsFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 
**RowLoadDocumentsFilter** | [**SearchDTO**](SearchDTO.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

