# IO.Swagger.Model.ImportDocumentMGParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddParameters** | [**ImportDocumentMGAddParameterDTO**](ImportDocumentMGAddParameterDTO.md) |  | [optional] 
**IsAsyncMode** | **bool?** | Asynchronous processing | [optional] [default to false]
**CodLayout** | **string** | Code Layout | 
**StreamFileImport** | **string** | Stream File Import | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

