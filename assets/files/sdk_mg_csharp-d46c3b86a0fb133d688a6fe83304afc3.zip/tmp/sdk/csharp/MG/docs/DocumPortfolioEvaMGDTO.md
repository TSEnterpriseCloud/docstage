# IO.Swagger.Model.DocumPortfolioEvaMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StatoRiga** | **double?** | Riga - STATO_RIGA | [optional] 
**CodArtDo30** | **string** | CodArt | [optional] 
**OpzioneDo30** | **string** | Variante | [optional] 
**CliforDo11** | **double?** | Cliente | [optional] 
**DocumDo11** | **string** | Codice | [optional] 
**DatadocDo11** | **DateTime?** | Data | [optional] 
**NumdocDo11** | **double?** | Numero | [optional] 
**SezdocDo11** | **string** | Sez. | [optional] 
**ProgVisuastaDo30** | **double?** | Riga | [optional] 
**Prior** | **double?** | Prior. | [optional] 
**Datacons** | **DateTime?** | Consegna | [optional] 
**Rifdata** | **string** | R/C | [optional] 
**Qta1Do30** | **double?** | Qta | [optional] 
**Qtagiac** | **double?** | Giac. utilizz | [optional] 
**Qtaord** | **double?** | Disp. utilizz. | [optional] 
**QtaTrasformazione** | **double?** | Qta trasf. | [optional] 
**GiacenzaDisponibileUm1** | **double?** | Giac. disponibile | [optional] 
**DescartMg87** | **string** | Descrizione articolo | [optional] 
**RagsoanagCg16** | **string** | Ragione sociale | [optional] 
**GiacAtt** | **double?** | Giacenza Att. | [optional] 
**GiacEff** | **double?** | Giacenza Eff. | [optional] 
**GiacdispAllaData** | **double?** | Disp. alla data | [optional] 
**OrdFor** | **double?** | Ordinato For. | [optional] 
**OrdProd** | **double?** | Ordinato Prod. | [optional] 
**ImpCli** | **double?** | Impegnato Cli. | [optional] 
**ImpProd** | **double?** | Impegnato Prod. | [optional] 
**ImpClav** | **double?** | Impegnato C/L. | [optional] 
**QtaBloccata** | **double?** | Blocco spedizione | [optional] 
**ImportoRigares** | **double?** | Importo riga residuo | [optional] 
**ImportoDo30** | **double?** | Importo riga | [optional] 
**TotDocres** | **double?** | Importo merce residuo | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

