# IO.Swagger.Model.DocumentoPortfolioEvadInMGDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidSession** | **string** | Processing Unique Guid Session | [optional] 
**LimiteEvadibilita** | **int?** | Evadability Limit (Filter Criteria) | 
**TipoEvadibilita** | **int?** | Evadibility type&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - All Items&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - For specific item&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - All Documents&lt;/li&gt;&lt;/ul&gt; | [optional] 
**CodArt** | **string** | ItemWH (Only for Evadibility type &#x3D; 1) | [optional] 
**Variante** | **string** | ItemWH (Only for Evadibility type &#x3D; 1 And CodArt setted) | [optional] 
**IsAsyncMode** | **bool?** | Elaboration Mode (Sync/Async) | 
**MinExpire** | **int?** | Minute Expire Guid Rows | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

