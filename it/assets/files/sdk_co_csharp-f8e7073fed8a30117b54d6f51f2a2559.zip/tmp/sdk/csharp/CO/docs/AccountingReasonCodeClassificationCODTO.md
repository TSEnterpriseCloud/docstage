# IO.Swagger.Model.AccountingReasonCodeClassificationCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descr** | **string** | CGD1_DESCR - Descrizione classificazione | [optional] 
**Id** | **double?** | CGD1_ID - Id classificazione (Required only in PUT/PATCH) | [optional] 
**IdmediaCg99** | **double?** | CGD1_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Tipologia** | **string** | CGD1_TIPOLOGIA - Codice classificazione | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

