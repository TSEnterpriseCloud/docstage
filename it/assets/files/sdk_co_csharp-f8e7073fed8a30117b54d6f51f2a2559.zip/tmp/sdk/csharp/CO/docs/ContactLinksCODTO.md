# IO.Swagger.Model.ContactLinksCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceCg16** | **int?** | CO03_CODICE_CG16 - Codice anagrafica | 
**FlgPref** | **double?** | CO03_FLGPREF - Preferenziale | [optional] [default to 0]
**Id** | **double?** | CO03_ID - ID (Required only in PUT/PATCH) | [optional] 
**IdCo02** | **double?** | CO03_ID_CO02 - Codice contatto | 
**Rowversion** | **byte[]** | CO03_ROWVERSION - RowVersion | [optional] 
**TipoCo01** | **string** | CO03_TIPO_CO01 - Tipo Cont./Rif. Azienda | 
**ContactSubject** | [**ContactSubjectCODTO**](ContactSubjectCODTO.md) |  | 
**ContactType** | [**ContactTypeCODTO**](ContactTypeCODTO.md) |  | 
**GeneralMasterData** | [**GeneralMasterDataCODTO**](GeneralMasterDataCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

