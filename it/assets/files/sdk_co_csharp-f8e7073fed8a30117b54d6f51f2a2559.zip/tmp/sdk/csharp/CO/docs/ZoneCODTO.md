# IO.Swagger.Model.ZoneCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AreaMg08** | **string** | MG09_AREA_MG08 - Area | 
**CodiceZona** | **string** | MG09_ZONA - Zona | 
**Descrzona** | **string** | MG09_DESCRZONA - Descrizione | [optional] 
**DittaCg18** | **double?** | MG09_DITTA_CG18 - Ditta | [optional] [default to 0]
**Idprov** | **int?** | MG09_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**MacroareaMg08** | **string** | MG09_MACROAREA_MG08 - Macroarea | 
**TipocfMg08** | **double?** | MG09_TIPOCF_MG08 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

