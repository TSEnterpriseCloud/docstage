# IO.Swagger.Model.StateCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdStato** | **int?** | Stete code | [optional] 
**Description** | **string** | Description state | [optional] 
**Seq** | **int?** | State sequence number | [optional] 
**IndTipoStato** | **int?** | Status type indicator: 0 - standard status, 1 - decision status, 2 - authorized status, 3 - unauthorized status | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

