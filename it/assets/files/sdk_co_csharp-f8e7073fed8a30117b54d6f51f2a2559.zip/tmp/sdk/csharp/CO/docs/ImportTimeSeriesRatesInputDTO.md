# IO.Swagger.Model.ImportTimeSeriesRatesInputDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StartDate** | **DateTime?** |  | [optional] 
**EndDate** | **DateTime?** |  | [optional] 
**BaseCurrencyIsoCode** | **string** |  | [optional] 
**CurrencyIsoCode** | **string** |  | [optional] 
**Overwrite** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

