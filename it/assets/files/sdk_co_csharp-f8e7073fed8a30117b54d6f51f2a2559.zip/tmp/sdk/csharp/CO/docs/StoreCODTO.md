# IO.Swagger.Model.StoreCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descrizione** | **string** | CG7A_DESCRIZIONE - Descrizione | [optional] 
**DittaCg18** | **double?** | CG7A_DITTA_CG18 - Ditta | 
**Puntoven** | **double?** | CG7A_PUNTOVEN - Codice punto vendita | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

