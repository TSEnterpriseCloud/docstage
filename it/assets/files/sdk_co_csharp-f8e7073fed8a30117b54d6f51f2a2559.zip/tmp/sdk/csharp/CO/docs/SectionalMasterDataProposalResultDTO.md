# IO.Swagger.Model.SectionalMasterDataProposalResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool?** |  | [optional] 
**SectionalData** | [**SectionalMasterDataProposalInfoDTO**](SectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**SelfInvoiceSectionalData** | [**SectionalMasterDataProposalInfoDTO**](SectionalMasterDataProposalInfoDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

