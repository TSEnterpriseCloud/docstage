# IO.Swagger.Model.MacroCategoryCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descrmacrocat** | **string** | MG10_DESCRMACROCAT - Descrizione | [optional] 
**DittaCg18** | **double?** | MG10_DITTA_CG18 - Ditta | [optional] [default to 0]
**Macrocat** | **string** | MG10_MACROCAT - Macrocategoria | 
**Tipocf** | **double?** | MG10_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**Categorie** | [**List&lt;CategoryCODTO&gt;**](CategoryCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

