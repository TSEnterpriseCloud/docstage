# IO.Swagger.Model.RegionCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdRegion** | **int?** | CP01_ID - Cod. Regione | 
**IstatCapitalCityCode** | **string** | CP01_CODISTATCAPOLUOGO - Codice ISTAT capoluogo | 
**IstatCode** | **string** | CP01_CODISTAT - Codice ISTAT | 
**Name** | **string** | CP01_DENOMINAZIONE - Regione | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

