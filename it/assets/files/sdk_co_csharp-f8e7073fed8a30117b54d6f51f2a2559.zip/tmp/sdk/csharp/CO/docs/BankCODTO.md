# IO.Swagger.Model.BankCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodBicswift** | **string** | CG12_CODBICSWIFT - Codice BIC SWIFT | [optional] 
**CodiceBanca** | **double?** | CG12_BANCA - ABI-Banca | 
**Descrizione** | **string** | CG12_DESCR - Descrizione | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

