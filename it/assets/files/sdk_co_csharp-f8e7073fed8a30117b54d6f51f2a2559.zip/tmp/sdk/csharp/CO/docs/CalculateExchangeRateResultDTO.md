# IO.Swagger.Model.CalculateExchangeRateResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**TipoCambioRecuperato** | **int?** |  | [optional] 
**NumeroDecimali** | **int?** |  | [optional] 
**Cambio** | **double?** |  | [optional] 
**DataCambio** | **DateTime?** |  | [optional] 
**IndicatoreCertoIncerto** | **int?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

