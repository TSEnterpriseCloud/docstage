# IO.Swagger.Model.CurrentStateHistoryCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentState** | [**StateCODTO**](StateCODTO.md) |  | [optional] 
**StatusOperationHistory** | [**List&lt;HistoryStateCODTO&gt;**](HistoryStateCODTO.md) | List of state change operations performed. | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

