# IO.Swagger.Model.SetStateParameterDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GuidObject** | **Guid?** | Guid of the object you want to change the state. | [optional] 
**NewState** | **int?** | New state to set if there is a current state | [optional] 
**EntityCodeForDefault** | **int?** | Entity code to find any default. Managed values: 1&#x3D;Customers 2&#x3D;Suppliers 6&#x3D;Items 7&#x3D;Document header 8&#x3D;Document row | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

