# IO.Swagger.Model.VatCodeDuplicationParametersCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SourceVatCode** | **string** |  | [optional] 
**NewVatCode** | **string** |  | [optional] 
**NewVatCodeDescription** | **string** |  | [optional] 
**IsDuplLangDescriptions** | **bool?** |  | [optional] 
**IsDuplExtendedAttribute** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

