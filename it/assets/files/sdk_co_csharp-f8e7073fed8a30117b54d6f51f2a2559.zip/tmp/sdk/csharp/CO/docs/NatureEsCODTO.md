# IO.Swagger.Model.NatureEsCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CG2M_CODICE - Codice | 
**Datafineval** | **DateTime?** | CG2M_DATAFINEVAL - Datafineval | [optional] 
**Datainival** | **DateTime?** | CG2M_DATAINIVAL - Datainival | [optional] 
**Descr** | **string** | CG2M_DESCR - Descrizione | 
**Id** | **int?** | CG2M_ID - Codice | 
**Rowversion** | **byte[]** | CG2M_ROWVERSION - Rowversion | [optional] 
**NatureAssCO** | [**List&lt;NatureAssCODTO&gt;**](NatureAssCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

