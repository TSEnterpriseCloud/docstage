# IO.Swagger.Api.IEExportCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentCOIEExportCOCustomersupplierPost**](IEExportCOApi.md#apiv1environmentcoieexportcocustomersupplierpost) | **POST** /api/v1/{environment}/CO/IEExportCO/customersupplier | Export Customers/Suppliers based on the required parameters

<a name="apiv1environmentcoieexportcocustomersupplierpost"></a>
# **ApiV1EnvironmentCOIEExportCOCustomersupplierPost**
> ImportExportResultDTO ApiV1EnvironmentCOIEExportCOCustomersupplierPost (ExportCustomerSupplierCOParameterDTO body, string authorizationScope, string environment, string acceptLanguage = null, string company = null, string user = null)

Export Customers/Suppliers based on the required parameters

Export Customers/Suppliers based on the required parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOIEExportCOCustomersupplierPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new IEExportCOApi();
            var body = new ExportCustomerSupplierCOParameterDTO(); // ExportCustomerSupplierCOParameterDTO | Export Customers/Suppliers parameters
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Export Customers/Suppliers based on the required parameters
                ImportExportResultDTO result = apiInstance.ApiV1EnvironmentCOIEExportCOCustomersupplierPost(body, authorizationScope, environment, acceptLanguage, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling IEExportCOApi.ApiV1EnvironmentCOIEExportCOCustomersupplierPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ExportCustomerSupplierCOParameterDTO**](ExportCustomerSupplierCOParameterDTO.md)| Export Customers/Suppliers parameters | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
