# IO.Swagger.Model.ContactTypeCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Codice** | **string** | CO01_CODICE - Codice tipo contatto/riferimento azienda | 
**Descr** | **string** | CO01_DESCR - Descrizione | 
**FlgUsosoll** | **int?** | CO01_FLGUSOSOLL - Utilizza per solleciti pagamento | [optional] 
**Rowversion** | **byte[]** | CO01_ROWVERSION - RowVersion | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

