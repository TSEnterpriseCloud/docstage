# IO.Swagger.Model.PgmExecDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdTaskScheduled** | **string** | Id for Scheduled Task | 
**TimeoutSeconds** | **int?** | Timeout in seconds for Scheduled Task | [optional] [default to 90]
**SkipIfRunning** | **bool?** | Skip if a task with same id is running | [optional] [default to true]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

