# IO.Swagger.Model.CurrentStateCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CurrentState** | [**StateCODTO**](StateCODTO.md) |  | [optional] 
**AvailableStates** | [**List&lt;StateCODTO&gt;**](StateCODTO.md) | List of available states reachable from the current state. | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

