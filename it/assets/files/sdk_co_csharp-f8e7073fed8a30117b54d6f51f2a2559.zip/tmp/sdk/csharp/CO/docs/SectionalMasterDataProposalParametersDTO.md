# IO.Swagger.Model.SectionalMasterDataProposalParametersDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Anno** | **double?** |  | [optional] 
**Causale** | **string** |  | [optional] 
**CodAttivita** | **double?** |  | [optional] 
**CalcolaProtocollo** | **bool?** |  | [optional] 
**TipoMovimento** | **double?** |  | [optional] 
**IgnoraCodAttivita** | **bool?** |  | [optional] 
**IgnoraProtocollazioneMovimenti** | **bool?** |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

