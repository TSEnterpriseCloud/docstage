# IO.Swagger.Model.OfficePACODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cap** | **string** | CG1M_CAP - Cap | [optional] 
**CodDestin** | **string** | CG1M_CODDESTIN - Codice destinatario | 
**Codice** | **string** | CG1M_CODICE - Codice | 
**CodiceCg16** | **int?** | CG1M_CODICE_CG16 - Codice anagrafica generale | 
**Comune** | **string** | CG1M_COMUNE - Comune | [optional] 
**FlgPreferenziale** | **int?** | CG1M_FLGPREFERENZIALE - Preferenziale&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**Idprovincia** | **int?** | CG1M_IDPROVINCIA - Cod. Provincia | [optional] [default to 0]
**Idregione** | **int?** | CG1M_IDREGIONE - Cod. Regione | [optional] [default to 0]
**IndIrizzo** | **string** | CG1M_INDIRIZZO - Indirizzo | [optional] 
**IndTypeb2b** | **int?** | CG1M_INDTYPEB2B - Instradamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;99&lt;/i&gt; - Non attivo&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - FEPA&lt;/li&gt;&lt;li&gt;&lt;i&gt;6&lt;/i&gt; - FEPR&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 99]
**LastupdateB2b** | **DateTime?** | CG1M_LASTUPDATE_B2B - Data ultimo aggiornamento | [optional] 
**Nome** | **string** | CG1M_NOME - Denominazione | 
**TipocfCg44** | **double?** | CG1M_TIPOCF_CG44 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

