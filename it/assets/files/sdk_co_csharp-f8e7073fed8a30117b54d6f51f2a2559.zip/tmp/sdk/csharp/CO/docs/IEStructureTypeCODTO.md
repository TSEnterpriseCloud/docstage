# IO.Swagger.Model.IEStructureTypeCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClassExport** | **string** | IE21_CLSEXPORT - Classe export | [optional] 
**ClassImport** | **string** | IE21_CLSIMPORT - Classe import | [optional] 
**CodStructureType** | **int?** | IE21_STRUTTURA - Struttura | 
**Description** | **string** | IE21_DESCRIZIONE - Descrizione struttura | 
**ExcludeFlag** | **double?** | IE21_FLGESCLUDI - Escludi&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**SortingEnabledFlag** | **double?** | IE21_FLGRICORD - Ordinamento&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - No&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Si&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeImpExp** | **double?** | IE21_INDIMPEXP - Modalità Import/Export&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Import/Export&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Import&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Export&lt;/li&gt;&lt;/ul&gt; | [optional] 
**TypeProcedure** | **double?** | IE21_INDTIPOPROC - Tipo procedura | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

