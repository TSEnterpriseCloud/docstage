# IO.Swagger.Model.HistoryStateCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdHistory** | **long?** | Id History | [optional] 
**IdStatus** | **int?** | Id History Status | [optional] 
**ValidityDate** | **DateTime?** | History Validity Date | [optional] 
**UpdateDate** | **DateTime?** | History Update Date | [optional] 
**HistoryAuto** | **int?** | History Auto | [optional] 
**StatusDescription** | **string** | History Status Description | [optional] 
**FlowDescription** | **string** | History Flow Description | [optional] 
**UserDescription** | **string** | History User Description | [optional] 
**HistoryDelete** | **int?** | History Delete | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

