# IO.Swagger.Model.SubCategoryCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CategMg11** | **string** | MG12_CATEG_MG11 - Categoria | 
**Descrsottocat** | **string** | MG12_DESCRSOTTOCAT - Descrizione | [optional] 
**DittaCg18** | **double?** | MG12_DITTA_CG18 - Ditta | [optional] [default to 0]
**MacrocatMg11** | **string** | MG12_MACROCAT_MG11 - Macrocategoria | 
**Sottcat** | **string** | MG12_SOTTCAT - Sottocategoria | 
**TipocfMg11** | **double?** | MG12_TIPOCF_MG11 - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

