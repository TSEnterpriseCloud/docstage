# IO.Swagger.Api.IEImportCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentCOIEImportCOCustomersupplierPost**](IEImportCOApi.md#apiv1environmentcoieimportcocustomersupplierpost) | **POST** /api/v1/{environment}/CO/IEImportCO/customersupplier | Import Customers/Suppliers based on the required parameters

<a name="apiv1environmentcoieimportcocustomersupplierpost"></a>
# **ApiV1EnvironmentCOIEImportCOCustomersupplierPost**
> ImportExportResultDTO ApiV1EnvironmentCOIEImportCOCustomersupplierPost (ImportCustomerSupplierCOParameterDTO body, string authorizationScope, string environment, string acceptLanguage = null, string company = null, string user = null)

Import Customers/Suppliers based on the required parameters

Import Customers/Suppliers based on the required parameters

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOIEImportCOCustomersupplierPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new IEImportCOApi();
            var body = new ImportCustomerSupplierCOParameterDTO(); // ImportCustomerSupplierCOParameterDTO | Import Customers/Suppliers parameters
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Import Customers/Suppliers based on the required parameters
                ImportExportResultDTO result = apiInstance.ApiV1EnvironmentCOIEImportCOCustomersupplierPost(body, authorizationScope, environment, acceptLanguage, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling IEImportCOApi.ApiV1EnvironmentCOIEImportCOCustomersupplierPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ImportCustomerSupplierCOParameterDTO**](ImportCustomerSupplierCOParameterDTO.md)| Import Customers/Suppliers parameters | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
