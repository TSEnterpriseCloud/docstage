# IO.Swagger.Model.AreaCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodiceAreaMG** | **string** | MG08_AREA - Area | 
**Descrarea** | **string** | MG08_DESCRAREA - Descrizione | [optional] 
**DittaCg18** | **double?** | MG08_DITTA_CG18 - Ditta | [optional] [default to 0]
**Idprov** | **int?** | MG08_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**MacroareaMg07** | **string** | MG08_MACROAREA_MG07 - Macroarea | 
**TipocfMg07** | **double?** | MG08_TIPOCF_MG07 - Tipo Cliente / Fornitore&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] 
**Zone** | [**List&lt;ZoneCODTO&gt;**](ZoneCODTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

