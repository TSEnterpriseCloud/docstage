# IO.Swagger.Model.ProtocolCalculationResultDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExecutionResult** | **bool?** |  | [optional] 
**Numdoc** | **double?** |  | [optional] 
**Tipodocrif** | **double?** |  | [optional] 
**Datadoc** | **DateTime?** |  | [optional] 
**NumDocOrigData** | [**NumDocOrigProposalDTO**](NumDocOrigProposalDTO.md) |  | [optional] 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

