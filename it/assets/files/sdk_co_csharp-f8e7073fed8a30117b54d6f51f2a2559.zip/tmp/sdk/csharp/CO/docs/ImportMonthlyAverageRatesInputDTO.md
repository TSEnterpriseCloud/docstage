# IO.Swagger.Model.ImportMonthlyAverageRatesInputDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BaseCurrencyIsoCode** | **List&lt;string&gt;** |  | [optional] 
**ReferenceYear** | **int?** |  | [optional] 
**ReferenceMonth** | **int?** |  | [optional] 
**Overwrite** | **bool?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

