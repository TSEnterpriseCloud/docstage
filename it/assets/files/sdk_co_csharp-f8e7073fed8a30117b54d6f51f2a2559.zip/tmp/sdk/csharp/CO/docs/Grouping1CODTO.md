# IO.Swagger.Model.Grouping1CODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodRaggrcf1** | **string** | MG31_CODRAGGRCF1 - Raggruppamento 1 | 
**Descraggrcf1** | **string** | MG31_DESCRAGGRCF1 - Descrizione | [optional] 
**DittaCg18** | **double?** | MG31_DITTA_CG18 - Ditta | [optional] [default to 0]
**IdmediaCg99** | **double?** | MG31_IDMEDIA_CG99 - ID HyperMedia | [optional] 
**Idprov** | **int?** | MG31_IDPROV - IdProv (Required only in PUT/PATCH) | [optional] 
**Tipocf** | **double?** | MG31_TIPOCF - Tipo Cli/For&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; -  Cliente&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; -  Fornitore&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

