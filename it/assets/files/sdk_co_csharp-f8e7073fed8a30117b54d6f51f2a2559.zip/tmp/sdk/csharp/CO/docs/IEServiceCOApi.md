# IO.Swagger.Api.IEServiceCOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentCOIEServiceCOGuidProcessGet**](IEServiceCOApi.md#apiv1environmentcoieservicecoguidprocessget) | **GET** /api/v1/{environment}/CO/IEServiceCO/{GuidProcess} | Get by Guid Session result of import/export

<a name="apiv1environmentcoieservicecoguidprocessget"></a>
# **ApiV1EnvironmentCOIEServiceCOGuidProcessGet**
> ImportExportResultDTO ApiV1EnvironmentCOIEServiceCOGuidProcessGet (string guidProcess, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Get by Guid Session result of import/export

Get by Guid Session result of import/export

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOIEServiceCOGuidProcessGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new IEServiceCOApi();
            var guidProcess = guidProcess_example;  // string | Guid to get the process import/export
            var environment = environment_example;  // string | 
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by Guid Session result of import/export
                ImportExportResultDTO result = apiInstance.ApiV1EnvironmentCOIEServiceCOGuidProcessGet(guidProcess, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling IEServiceCOApi.ApiV1EnvironmentCOIEServiceCOGuidProcessGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **guidProcess** | **string**| Guid to get the process import/export | 
 **environment** | **string**|  | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]

### Return type

[**ImportExportResultDTO**](ImportExportResultDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
