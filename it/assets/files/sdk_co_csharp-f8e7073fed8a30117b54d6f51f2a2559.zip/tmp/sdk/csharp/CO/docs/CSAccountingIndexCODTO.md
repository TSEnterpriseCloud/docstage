# IO.Swagger.Model.CSAccountingIndexCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CodCat** | **string** | MGA3_CODCAT -  Codice | 
**Descr** | **string** | MGA3_DESCR - Descrizione | [optional] 
**DittaCg18** | **double?** | MGA3_DITTA_CG18 - Ditta | 
**TipocfCg44** | **double?** | MGA3_TIPOCF_CG44 - Tipo cliente fornitore | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

