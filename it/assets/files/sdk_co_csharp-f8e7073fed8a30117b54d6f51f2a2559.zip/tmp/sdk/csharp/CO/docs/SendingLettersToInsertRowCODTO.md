# IO.Swagger.Model.SendingLettersToInsertRowCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IdCliFor** | **int?** |  | [optional] 
**AnnoCompetenza** | **int?** |  | [optional] 
**ValidaDa** | **DateTime?** |  | [optional] 
**ValidaA** | **DateTime?** |  | [optional] 
**DataStampa** | **DateTime?** |  | [optional] 
**IndTipoDich** | **double?** |  | [optional] 
**Ammontare** | **double?** |  | [optional] 
**Dogana** | **string** |  | [optional] 
**IvaEsenz** | **string** |  | [optional] 
**Note** | **string** |  | [optional] 
**CodRap** | **int?** |  | [optional] 
**CodCarica** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

