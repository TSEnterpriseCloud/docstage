# IO.Swagger.Api.CustSupplDataInvoicePACOApi

All URIs are relative to *https://apicsdemo.teamsystem.io*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOGet**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacoget) | **GET** /api/v1/{environment}/CO/CustSupplDataInvoicePACO | Get new
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDelete**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacoiddelete) | **DELETE** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/{id} | Delete
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGet**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacoidget) | **GET** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/{id} | Get by ID
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatch**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacoidpatch) | **PATCH** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/{id} | Update partial
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPut**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacoidput) | **PUT** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/{id} | Update
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOPost**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacopost) | **POST** /api/v1/{environment}/CO/CustSupplDataInvoicePACO | Create
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePost**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacovalidatepost) | **POST** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/validate | Validate
[**ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPost**](CustSupplDataInvoicePACOApi.md#apiv1environmentcocustsuppldatainvoicepacovalidatepropertiespost) | **POST** /api/v1/{environment}/CO/CustSupplDataInvoicePACO/validateProperties | Validation of one on more properties of Type

<a name="apiv1environmentcocustsuppldatainvoicepacoget"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOGet**
> CustSupplDataInvoicePACODTO ApiV1EnvironmentCOCustSupplDataInvoicePACOGet (string op, string environment, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Get new

Get an empty object of type corresponding

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var op = op_example;  // string | The value must be 'new'
            var environment = environment_example;  // string | 
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get new
                CustSupplDataInvoicePACODTO result = apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOGet(op, environment, authorizationScope, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **op** | **string**| The value must be &#x27;new&#x27; | 
 **environment** | **string**|  | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]

### Return type

[**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacoiddelete"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDelete**
> void ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDelete (string id, string environment, string tipocfCg44, string codiceCg16, string authorizationScope, string company = null, string user = null, string acceptLanguage = null)

Delete

Deleting object of type 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDeleteExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var id = id_example;  // string | 
            var environment = environment_example;  // string | 
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Delete
                apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDelete(id, environment, tipocfCg44, codiceCg16, authorizationScope, company, user, acceptLanguage);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdDelete: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string**|  | 
 **environment** | **string**|  | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacoidget"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGet**
> CustSupplDataInvoicePACODTO ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGet (string id, string environment, string tipocfCg44, string codiceCg16, string authorizationScope, string dlevel = null, string dlevelkey = null, string company = null, string user = null, string acceptLanguage = null)

Get by ID

Get an object of type corresponding the requested id

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGetExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var id = id_example;  // string | Id to get the object
            var environment = environment_example;  // string | 
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var dlevel = dlevel_example;  // string | Serialization level (optional) 
            var dlevelkey = dlevelkey_example;  // string | Serialization level key (optional) 
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)

            try
            {
                // Get by ID
                CustSupplDataInvoicePACODTO result = apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGet(id, environment, tipocfCg44, codiceCg16, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string**| Id to get the object | 
 **environment** | **string**|  | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **dlevel** | **string**| Serialization level | [optional] 
 **dlevelkey** | **string**| Serialization level key | [optional] 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]

### Return type

[**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacoidpatch"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatch**
> void ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatch (Object body, string authorizationScope, string tipocfCg44, string codiceCg16, string id, string environment, string acceptLanguage = null, string force = null, string op = null, string company = null, string user = null)

Update partial

Patching an object of type

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatchExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var body = new Object(); // Object | Object of type to patch
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var id = id_example;  // string | 
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var force = force_example;  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = op_example;  // string | Set 'reload', if you want the DTO updated in the response request (optional) 
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Update partial
                apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatch(body, authorizationScope, tipocfCg44, codiceCg16, id, environment, acceptLanguage, force, op, company, user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPatch: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Object**](Object.md)| Object of type to patch | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **id** | **string**|  | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **force** | **string**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **string**| Set &#x27;reload&#x27;, if you want the DTO updated in the response request | [optional] 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacoidput"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPut**
> CustSupplDataInvoicePACODTO ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPut (CustSupplDataInvoicePACODTO body, string authorizationScope, string tipocfCg44, string codiceCg16, string id, string environment, string acceptLanguage = null, string force = null, string op = null, string company = null, string user = null)

Update

Updating an object of type

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPutExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var body = new CustSupplDataInvoicePACODTO(); // CustSupplDataInvoicePACODTO | Object of type to update
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var id = id_example;  // string | 
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var force = force_example;  // string | The warning/s code to bypass (separated by ‘,’) during the execution (optional) 
            var op = op_example;  // string | Set 'reload', if you want the DTO updated in the response request, otherwise will be returned null value (optional) 
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Update
                CustSupplDataInvoicePACODTO result = apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPut(body, authorizationScope, tipocfCg44, codiceCg16, id, environment, acceptLanguage, force, op, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOIdPut: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)| Object of type to update | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **id** | **string**|  | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **force** | **string**| The warning/s code to bypass (separated by ‘,’) during the execution | [optional] 
 **op** | **string**| Set &#x27;reload&#x27;, if you want the DTO updated in the response request, otherwise will be returned null value | [optional] 
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacopost"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOPost**
> CustSupplDataInvoicePACODTO ApiV1EnvironmentCOCustSupplDataInvoicePACOPost (CustSupplDataInvoicePACODTO body, string authorizationScope, string environment, string acceptLanguage = null, string company = null, string user = null)

Create

Creating new object of type

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var body = new CustSupplDataInvoicePACODTO(); // CustSupplDataInvoicePACODTO | Object of type to create
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Create
                CustSupplDataInvoicePACODTO result = apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOPost(body, authorizationScope, environment, acceptLanguage, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)| Object of type to create | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacovalidatepost"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePost**
> void ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePost (CustSupplDataInvoicePACODTO body, string authorizationScope, string tipocfCg44, string codiceCg16, string environment, string acceptLanguage = null, string company = null, string user = null)

Validate

Validation of object of type

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var body = new CustSupplDataInvoicePACODTO(); // CustSupplDataInvoicePACODTO | Object of type to validate
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var environment = environment_example;  // string | 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Validate
                apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePost(body, authorizationScope, tipocfCg44, codiceCg16, environment, acceptLanguage, company, user);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CustSupplDataInvoicePACODTO**](CustSupplDataInvoicePACODTO.md)| Object of type to validate | 
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **environment** | **string**|  | 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

void (empty response body)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="apiv1environmentcocustsuppldatainvoicepacovalidatepropertiespost"></a>
# **ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPost**
> ValidateDTO ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPost (string authorizationScope, string tipocfCg44, string codiceCg16, string environment, string body = null, string acceptLanguage = null, string company = null, string user = null)

Validation of one on more properties of Type

Validation of object of type

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPostExample
    {
        public void main()
        {
            // Configure HTTP basic authorization: Basic
            Configuration.Default.Username = "YOUR_USERNAME";
            Configuration.Default.Password = "YOUR_PASSWORD";

            var apiInstance = new CustSupplDataInvoicePACOApi();
            var authorizationScope = authorizationScope_example;  // string | The environment where this operation will be executed. This must match with the environment in the url.
            var tipocfCg44 = tipocfCg44_example;  // string | TipocfCg44 Mandatory to execute current action
            var codiceCg16 = codiceCg16_example;  // string | CodiceCg16 Mandatory to execute current action
            var environment = environment_example;  // string | 
            var body = new string(); // string |  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED<br> - The id of an existing object to validate properties, or '' if the object does not exist yet <br> (optional) 
            var acceptLanguage = acceptLanguage_example;  // string | Example for multilanguage (optional)  (default to it-IT)
            var company = company_example;  // string | Company code (optional) 
            var user = user_example;  // string | Application user (mandatory if the WebApi user does not have any mapped application user) (optional) 

            try
            {
                // Validation of one on more properties of Type
                ValidateDTO result = apiInstance.ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPost(authorizationScope, tipocfCg44, codiceCg16, environment, body, acceptLanguage, company, user);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CustSupplDataInvoicePACOApi.ApiV1EnvironmentCOCustSupplDataInvoicePACOValidatePropertiesPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorizationScope** | **string**| The environment where this operation will be executed. This must match with the environment in the url. | 
 **tipocfCg44** | **string**| TipocfCg44 Mandatory to execute current action | 
 **codiceCg16** | **string**| CodiceCg16 Mandatory to execute current action | 
 **environment** | **string**|  | 
 **body** | [**string**](string.md)|  - One or more key-value pairs where the key is the DTO property name and the value is value to validate * REQUIRED&lt;br&gt; - The id of an existing object to validate properties, or &#x27;&#x27; if the object does not exist yet &lt;br&gt; | [optional] 
 **acceptLanguage** | **string**| Example for multilanguage | [optional] [default to it-IT]
 **company** | **string**| Company code | [optional] 
 **user** | **string**| Application user (mandatory if the WebApi user does not have any mapped application user) | [optional] 

### Return type

[**ValidateDTO**](ValidateDTO.md)

### Authorization

[Basic](../README.md#Basic), [Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
