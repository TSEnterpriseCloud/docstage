# IO.Swagger.Model.CSCompanyBankCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CliforCg44** | **double?** | MG2H_CLIFOR_CG44 - Codice Cliente / Fornitore | 
**DittaCg18** | **double?** | MG2H_DITTA_CG18 - Ditta | 
**FlgPref** | **int?** | MG2H_FLGPREF - Banca preferenziale | 
**Id** | **int?** | MG2H_ID - ID (Required only in PUT/PATCH) | [optional] 
**ProgR** | **int?** | MG2H_PROGR - PROGR | 
**ProgREf08** | **double?** | MG2H_PROGR_EF08 - Codice banca aziendale | 
**Rowversion** | **byte[]** | MG2H_ROWVERSION - Rowversion | [optional] 
**TipocfCg44** | **double?** | MG2H_TIPOCF_CG44 - Tipo cliente fornitore | 
**CompanyBankCO** | [**CompanyBankCODTO**](CompanyBankCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

