# IO.Swagger.Model.UnitOfMeasureCODTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Descr** | **string** | CG0C_DESCR - Descrizione | [optional] 
**DittaCg18** | **double?** | CG0C_DITTA_CG18 - Ditta | 
**Fattconv** | **double?** | CG0C_FATTCONV - Fattore di conversione | [optional] [default to 1]
**IndOperatore** | **double?** | CG0C_INDOPERATORE - Operatore di conversione&lt;br&gt;&lt;ul&gt;&lt;li&gt;&lt;i&gt;0&lt;/i&gt; - Nessuno&lt;/li&gt;&lt;li&gt;&lt;i&gt;1&lt;/i&gt; - Moltiplicazione&lt;/li&gt;&lt;li&gt;&lt;i&gt;2&lt;/i&gt; - Divisione&lt;/li&gt;&lt;/ul&gt; | [optional] [default to 0]
**Umsigla** | **string** | CG0C_UMSIGLA - Sigla da visualizzare | 
**Sigla** | [**UMCodeCODTO**](UMCodeCODTO.md) |  | 
**ExtensionData** | [**List&lt;StringObjectKeyValuePair&gt;**](StringObjectKeyValuePair.md) |  | [optional] 
**AdditionalData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 
**PluginData** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

