'use strict';

var utils = require('../utils/writer.js');
var IEImportMG = require('../service/IEImportMGService');

module.exports.apiV1EnvironmentMGIEImportMGDocumentPOST = function apiV1EnvironmentMGIEImportMGDocumentPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  IEImportMG.apiV1EnvironmentMGIEImportMGDocumentPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
