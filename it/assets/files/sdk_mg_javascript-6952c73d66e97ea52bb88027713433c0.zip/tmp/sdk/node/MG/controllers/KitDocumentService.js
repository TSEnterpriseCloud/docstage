'use strict';

var utils = require('../utils/writer.js');
var KitDocumentService = require('../service/KitDocumentServiceService');

module.exports.apiV1EnvironmentMGKitDocumentServiceLoadkitPOST = function apiV1EnvironmentMGKitDocumentServiceLoadkitPOST (req, res, next, body, force, company, user, environment, authorizationScope, acceptLanguage) {
  KitDocumentService.apiV1EnvironmentMGKitDocumentServiceLoadkitPOST(body, force, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGKitDocumentServiceUnloadcompPOST = function apiV1EnvironmentMGKitDocumentServiceUnloadcompPOST (req, res, next, body, force, company, user, environment, authorizationScope, acceptLanguage) {
  KitDocumentService.apiV1EnvironmentMGKitDocumentServiceUnloadcompPOST(body, force, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
