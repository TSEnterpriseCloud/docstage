'use strict';


/**
 * Creation of component unloading documents from loading documents based on the required parameters
 * Creation of component unloading documents from loading documents based on the required parameters
 *
 * body KitLoadProductParameterDTO Creation of component unloading documents parameters
 * force String Force values (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns KitDocumentResultDTO
 **/
exports.apiV1EnvironmentMGKitDocumentServiceLoadkitPOST = function(body,force,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numRegLoadProductKit" : [ "numRegLoadProductKit", "numRegLoadProductKit" ],
  "numRegUnloadComp" : [ "numRegUnloadComp", "numRegUnloadComp" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Creation of component unloading documents from loading documents based on the required parameters
 * Creation of component unloading documents from loading documents based on the required parameters
 *
 * body KitUnloadComponentParameterDTO Creation of component unloading documents parameters
 * force String Force values (optional)
 * company String Company code (optional)
 * user String Application user (mandatory if the WebApi user does not have any mapped application user) (optional)
 * environment String 
 * authorizationScope String The environment where this operation will be executed. This must match with the environment in the url.
 * acceptLanguage String Example for multilanguage (optional)
 * returns KitDocumentResultDTO
 **/
exports.apiV1EnvironmentMGKitDocumentServiceUnloadcompPOST = function(body,force,company,user,environment,authorizationScope,acceptLanguage) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "numRegLoadProductKit" : [ "numRegLoadProductKit", "numRegLoadProductKit" ],
  "numRegUnloadComp" : [ "numRegUnloadComp", "numRegUnloadComp" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

