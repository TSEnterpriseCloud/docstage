'use strict';

var utils = require('../utils/writer.js');
var IEExportMG = require('../service/IEExportMGService');

module.exports.apiV1EnvironmentMGIEExportMGDocumentPOST = function apiV1EnvironmentMGIEExportMGDocumentPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  IEExportMG.apiV1EnvironmentMGIEExportMGDocumentPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
