'use strict';

var utils = require('../utils/writer.js');
var CustomerSupplierMG = require('../service/CustomerSupplierMGService');

module.exports.apiV1EnvironmentMGCustomerSupplierMGGET = function apiV1EnvironmentMGCustomerSupplierMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CustomerSupplierMG.apiV1EnvironmentMGCustomerSupplierMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierMGIdGET = function apiV1EnvironmentMGCustomerSupplierMGIdGET (req, res, next, id, environment, tipoCf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CustomerSupplierMG.apiV1EnvironmentMGCustomerSupplierMGIdGET(id, environment, tipoCf, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierMGValidatePOST = function apiV1EnvironmentMGCustomerSupplierMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierMG.apiV1EnvironmentMGCustomerSupplierMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierMGValidatePropertiesPOST = function apiV1EnvironmentMGCustomerSupplierMGValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierMG.apiV1EnvironmentMGCustomerSupplierMGValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
