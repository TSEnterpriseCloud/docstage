'use strict';

var utils = require('../utils/writer.js');
var CompanyDocumentMasterDataMG = require('../service/CompanyDocumentMasterDataMGService');

module.exports.apiV1EnvironmentMGCompanyDocumentMasterDataMGGET = function apiV1EnvironmentMGCompanyDocumentMasterDataMGGET (req, res, next, _op, environment, authorizationScope, company, user, acceptLanguage) {
  CompanyDocumentMasterDataMG.apiV1EnvironmentMGCompanyDocumentMasterDataMGGET(_op, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCompanyDocumentMasterDataMGIdGET = function apiV1EnvironmentMGCompanyDocumentMasterDataMGIdGET (req, res, next, id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CompanyDocumentMasterDataMG.apiV1EnvironmentMGCompanyDocumentMasterDataMGIdGET(id, environment, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePOST = function apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CompanyDocumentMasterDataMG.apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPOST = function apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CompanyDocumentMasterDataMG.apiV1EnvironmentMGCompanyDocumentMasterDataMGValidatePropertiesPOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
