'use strict';

var utils = require('../utils/writer.js');
var DocumentService = require('../service/DocumentServiceService');

module.exports.apiV1EnvironmentMGDocumentServiceDocprocessingstatusPOST = function apiV1EnvironmentMGDocumentServiceDocprocessingstatusPOST (req, res, next, body, loadEntireDomain, getTotalCount, company, user, environment, authorizationScope, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceDocprocessingstatusPOST(body, loadEntireDomain, getTotalCount, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceMultiplecreatePOST = function apiV1EnvironmentMGDocumentServiceMultiplecreatePOST (req, res, next, body, force, withvalidpreconditions, company, user, environment, authorizationScope, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceMultiplecreatePOST(body, force, withvalidpreconditions, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDELETE = function apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDELETE (req, res, next, id, environment, authorizationScope, progress, company, user, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceMultiplecreatehistoryIdDELETE(id, environment, authorizationScope, progress, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPOST = function apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPOST (req, res, next, body, force, withvalidpreconditions, company, user, guid, environment, authorizationScope, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceMultiplecreatereprocessGuidPOST(body, force, withvalidpreconditions, company, user, guid, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDELETE = function apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDELETE (req, res, next, id, environment, authorizationScope, company, user, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceOrderavailabilityIdDELETE(id, environment, authorizationScope, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceOrderavailabilityPOST = function apiV1EnvironmentMGDocumentServiceOrderavailabilityPOST (req, res, next, body, force, company, user, environment, authorizationScope, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceOrderavailabilityPOST(body, force, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGDocumentServiceTransformPOST = function apiV1EnvironmentMGDocumentServiceTransformPOST (req, res, next, body, force, company, user, environment, authorizationScope, acceptLanguage) {
  DocumentService.apiV1EnvironmentMGDocumentServiceTransformPOST(body, force, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
