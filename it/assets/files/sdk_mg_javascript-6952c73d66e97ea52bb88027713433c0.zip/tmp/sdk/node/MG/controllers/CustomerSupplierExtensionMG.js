'use strict';

var utils = require('../utils/writer.js');
var CustomerSupplierExtensionMG = require('../service/CustomerSupplierExtensionMGService');

module.exports.apiV1EnvironmentMGCustomerSupplierExtensionMGIdGET = function apiV1EnvironmentMGCustomerSupplierExtensionMGIdGET (req, res, next, id, environment, tipocfCg44, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage) {
  CustomerSupplierExtensionMG.apiV1EnvironmentMGCustomerSupplierExtensionMGIdGET(id, environment, tipocfCg44, authorizationScope, dlevel, dlevelkey, company, user, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierExtensionMGIdPATCH = function apiV1EnvironmentMGCustomerSupplierExtensionMGIdPATCH (req, res, next, body, force, _op, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierExtensionMG.apiV1EnvironmentMGCustomerSupplierExtensionMGIdPATCH(body, force, _op, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierExtensionMGIdPUT = function apiV1EnvironmentMGCustomerSupplierExtensionMGIdPUT (req, res, next, body, force, _op, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierExtensionMG.apiV1EnvironmentMGCustomerSupplierExtensionMGIdPUT(body, force, _op, tipocfCg44, company, user, id, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.apiV1EnvironmentMGCustomerSupplierExtensionMGValidatePOST = function apiV1EnvironmentMGCustomerSupplierExtensionMGValidatePOST (req, res, next, body, company, user, environment, authorizationScope, acceptLanguage) {
  CustomerSupplierExtensionMG.apiV1EnvironmentMGCustomerSupplierExtensionMGValidatePOST(body, company, user, environment, authorizationScope, acceptLanguage)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
